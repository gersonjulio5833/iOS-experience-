package com.iphoneexperience.launcher

import android.app.ActivityOptions
import android.app.NotificationManager
import android.app.SearchManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.Settings
import android.view.HapticFeedbackConstants
import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject

/**
 * Interface exposta à UI como window.IOSBridge.
 * Só utiliza APIs públicas. Quando o Android não permite alterar algo directamente,
 * devolve false e/ou abre o painel oficial correspondente.
 */
class Bridge(private val a: MainActivity) {

    private val ctx: Context get() = a

    @JavascriptInterface
    fun ready() { a.emitStatus() }

    // ---------- apps ----------
    @JavascriptInterface
    fun getApps(): String {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val arr = JSONArray()
        val seen = HashSet<String>()
        for (ri in pm.queryIntentActivities(intent, 0)) {
            val ai = ri.activityInfo ?: continue
            if (ai.packageName == ctx.packageName) continue
            val id = ComponentName(ai.packageName, ai.name).flattenToShortString()
            if (!seen.add(id)) continue
            arr.put(JSONObject()
                .put("id", id)
                .put("pkg", ai.packageName)
                .put("label", ri.loadLabel(pm).toString())
                .put("system", (ai.applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0))
        }
        return arr.toString()
    }

    /** Apps predefinidas por função (para lhes dar ícones estilo iOS). */
    @JavascriptInterface
    fun getRoles(): String {
        val pm = ctx.packageManager
        fun pkgFor(i: Intent): String? = try { pm.resolveActivity(i, 0)?.activityInfo?.packageName?.takeIf { it != "android" } } catch (_: Exception) { null }
        fun cat(c: String) = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, c)
        val o = JSONObject()
        mapOf(
            "phone" to Intent(Intent.ACTION_DIAL),
            "sms" to cat(Intent.CATEGORY_APP_MESSAGING),
            "browser" to cat(Intent.CATEGORY_APP_BROWSER),
            "camera" to Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
            "music" to cat(Intent.CATEGORY_APP_MUSIC),
            "calendar" to cat(Intent.CATEGORY_APP_CALENDAR),
            "gallery" to cat(Intent.CATEGORY_APP_GALLERY),
            "email" to cat(Intent.CATEGORY_APP_EMAIL),
            "maps" to cat(Intent.CATEGORY_APP_MAPS),
            "contacts" to cat(Intent.CATEGORY_APP_CONTACTS),
            "calculator" to cat(Intent.CATEGORY_APP_CALCULATOR),
            "clock" to Intent(android.provider.AlarmClock.ACTION_SHOW_ALARMS),
        ).forEach { (k, i) -> pkgFor(i)?.let { o.put(k, it) } }
        return o.toString()
    }

    @JavascriptInterface
    fun launchApp(id: String, x: Int, y: Int, w: Int, h: Int) {
        val cn = ComponentName.unflattenFromString(id) ?: return
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(cn)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        a.runOnUiThread {
            try {
                val opts = if (w > 0 && h > 0) ActivityOptions.makeClipRevealAnimation(a.webView, x, y, w, h).toBundle() else null
                a.startActivity(intent, opts)
            } catch (e: Exception) {
                try { ctx.packageManager.getLaunchIntentForPackage(cn.packageName)?.let { a.startActivity(it) } } catch (_: Exception) {}
            }
        }
    }

    @JavascriptInterface
    fun appDetails(pkg: String) = SystemInfo.start(a, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))

    @JavascriptInterface
    fun uninstall(pkg: String) {
        @Suppress("DEPRECATION")
        SystemInfo.start(a, Intent(Intent.ACTION_UNINSTALL_PACKAGE, Uri.parse("package:$pkg")))
    }

    // ---------- estado e controlos ----------
    @JavascriptInterface
    fun getStatus(): String = SystemInfo.status(a).toString()

    @JavascriptInterface
    fun setTorch(on: Boolean) {
        try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true } ?: return
            cm.setTorchMode(id, on)
            a.torchOn = on
        } catch (_: Exception) {}
    }

    @JavascriptInterface
    fun setBrightness(v: Float): Boolean {
        val value = v.coerceIn(0.01f, 1f)
        if (Settings.System.canWrite(ctx)) {
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, (value * 255).toInt())
            a.runOnUiThread { a.window.attributes = a.window.attributes.apply { screenBrightness = -1f } }
            return true
        }
        // Sem permissão: só ajusta o brilho enquanto o Launcher estiver visível.
        a.runOnUiThread { a.window.attributes = a.window.attributes.apply { screenBrightness = value } }
        return false
    }

    @JavascriptInterface
    fun setVolume(v: Float) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        try { am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(v * max), 0) } catch (_: Exception) {}
    }

    @JavascriptInterface
    fun setDnd(on: Boolean): Boolean {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) return false
        nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL)
        return true
    }

    @JavascriptInterface
    fun setRinger(mode: String): Boolean {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return try {
            am.ringerMode = when (mode) {
                "silent" -> AudioManager.RINGER_MODE_SILENT
                "vibrate" -> AudioManager.RINGER_MODE_VIBRATE
                else -> AudioManager.RINGER_MODE_NORMAL
            }
            true
        } catch (_: SecurityException) { false }
    }

    @JavascriptInterface
    fun setRotationLock(locked: Boolean): Boolean {
        if (!Settings.System.canWrite(ctx)) return false
        Settings.System.putInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (locked) 0 else 1)
        return true
    }

    @JavascriptInterface
    fun openPanel(name: String) = SystemInfo.openPanel(a, name)

    @JavascriptInterface
    fun openUrl(url: String) = SystemInfo.start(a, Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    @JavascriptInterface
    fun webSearch(q: String) {
        val i = Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q)
        if (!SystemInfo.start(a, i)) SystemInfo.start(a, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
    }

    // ---------- multimédia ----------
    @JavascriptInterface
    fun getMedia(): String = MediaHub.json()?.toString() ?: "null"

    @JavascriptInterface
    fun mediaAction(action: String, value: Double) = MediaHub.action(action, value.toLong())

    // ---------- notificações ----------
    @JavascriptInterface
    fun getNotifications(): String = NotifService.instance?.listJson()?.toString() ?: "[]"

    @JavascriptInterface
    fun openNotification(key: String) { NotifService.instance?.open(key) }

    @JavascriptInterface
    fun dismissNotification(key: String) { try { NotifService.instance?.cancelNotification(key) } catch (_: Exception) {} }

    @JavascriptInterface
    fun clearNotifications() { try { NotifService.instance?.cancelAllNotifications() } catch (_: Exception) {} }

    // ---------- outros ----------
    @JavascriptInterface
    fun getCall(): String = a.callJson()

    @JavascriptInterface
    fun requestPermission(name: String) {
        when (name) {
            "phone" -> a.requestPhone()
            "all" -> a.requestAllPermissions()
            "contacts" -> a.requestOne(android.Manifest.permission.READ_CONTACTS)
            "bluetooth" -> if (android.os.Build.VERSION.SDK_INT >= 31) a.requestOne(android.Manifest.permission.BLUETOOTH_CONNECT)
            "notifications" -> if (android.os.Build.VERSION.SDK_INT >= 33) a.requestOne(android.Manifest.permission.POST_NOTIFICATIONS)
            "overlay" -> SystemInfo.start(a, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + a.packageName)))
            "accessibility" -> SystemInfo.start(a, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }

    /** Pesquisa de contactos por nome ou número (requer READ_CONTACTS). Devolve [{name, number}]. */
    @JavascriptInterface
    fun searchContacts(q: String): String {
        val out = JSONArray()
        if (q.isBlank() || a.checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != android.content.pm.PackageManager.PERMISSION_GRANTED) return out.toString()
        try {
            val uri = android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_FILTER_URI.buildUpon().appendPath(q).build()
            a.contentResolver.query(uri, arrayOf(android.provider.ContactsContract.Contacts.DISPLAY_NAME, android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER), null, null, android.provider.ContactsContract.Contacts.DISPLAY_NAME + " ASC")?.use { c ->
                val seen = HashSet<String>()
                while (c.moveToNext() && out.length() < 8) {
                    val n = c.getString(0) ?: continue; val num = c.getString(1) ?: continue
                    if (seen.add(n + num.filter { it.isDigit() })) out.put(JSONObject().put("name", n).put("number", num))
                }
            }
        } catch (_: Exception) {}
        return out.toString()
    }

    @JavascriptInterface
    fun dial(number: String) = SystemInfo.start(a, Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))))

    /** Acções globais via serviço de acessibilidade: notifications, quickSettings, recents, lock. */
    @JavascriptInterface
    fun globalAction(name: String): Boolean = OverlayService.act(name)

    @JavascriptInterface
    fun setImmersive(on: Boolean) { a.hideStatusBar = on; a.applyImmersive() }

    @JavascriptInterface
    fun vibrate(ms: Int) {
        a.runOnUiThread {
            a.webView.performHapticFeedback(
                if (ms >= 15) HapticFeedbackConstants.LONG_PRESS else HapticFeedbackConstants.KEYBOARD_TAP,
                HapticFeedbackConstants.FLAG_IGNORE_VIEW_SETTING
            )
        }
    }
}
