package com.iphoneexperience.launcher.ime

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import java.text.Normalizer

@SuppressLint("ViewConstructor")
class KeyboardView(ctx: Context) : View(ctx) {

    var service: IosKeyboardService? = null
    var editorInfo: EditorInfo? = null
    var dark = false
        set(v) { field = v; invalidate() }

    private enum class Layer { ABC, NUM, SYM }
    private enum class T { CHAR, SHIFT, DEL, LAYER, SYMSWITCH, GLOBE, SPACE, ENTER, SPACER }
    private data class Key(val label: String, val type: T = T.CHAR, val weight: Float = 1f) { val rect = RectF() }

    private var layer = Layer.ABC
    private var shift = 1 // 0 desligado, 1 uma vez, 2 bloqueado
    private var lastShiftTap = 0L
    private var lastSpace = 0L
    private val d = resources.displayMetrics.density
    private val sugH = 44 * d
    private val keyH = 44 * d
    private val rowGap = 11 * d
    private val hGap = 6 * d
    private var rows: List<List<Key>> = emptyList()
    private var suggestions = listOf("Olá", "Obrigado", "Sim")
    private val sugRects = Array(3) { RectF() }
    private var pressed: Key? = null
    private var accents: List<String>? = null
    private var accentSel = 0
    private val handler = Handler(Looper.getMainLooper())
    private var longPress: Runnable? = null
    private var repeatDel: Runnable? = null

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.create("sans-serif", Typeface.NORMAL) }

    private val accentMap = mapOf(
        "a" to listOf("á", "à", "â", "ã", "ä"), "e" to listOf("é", "ê", "è", "ë"), "i" to listOf("í", "ì", "î", "ï"),
        "o" to listOf("ó", "ô", "õ", "ò", "ö"), "u" to listOf("ú", "ü", "ù", "û"), "c" to listOf("ç"), "n" to listOf("ñ")
    )

    init { buildRows() }

    private fun buildRows() {
        rows = when (layer) {
            Layer.ABC -> listOf(
                "qwertyuiop".map { Key(it.toString()) },
                listOf(Key("", T.SPACER, 0.5f)) + "asdfghjkl".map { Key(it.toString()) } + listOf(Key("", T.SPACER, 0.5f)),
                listOf(Key("⇧", T.SHIFT, 1.35f), Key("", T.SPACER, 0.15f)) + "zxcvbnm".map { Key(it.toString()) } + listOf(Key("", T.SPACER, 0.15f), Key("⌫", T.DEL, 1.35f)),
                listOf(Key("123", T.LAYER, 1.25f), Key("🌐", T.GLOBE, 1.1f), Key("espaço", T.SPACE, 4.8f), Key(enterLabel(), T.ENTER, 2.2f))
            )
            Layer.NUM, Layer.SYM -> {
                val r1 = if (layer == Layer.NUM) "1234567890" else "[]{}#%^*+="
                val r2 = if (layer == Layer.NUM) listOf("-", "/", ":", ";", "(", ")", "€", "&", "@", "\"") else listOf("_", "\\", "|", "~", "<", ">", "$", "£", "¥", "•")
                listOf(
                    r1.map { Key(it.toString()) },
                    r2.map { Key(it) },
                    listOf(Key(if (layer == Layer.NUM) "#+=" else "123", T.SYMSWITCH, 1.35f), Key("", T.SPACER, 0.5f)) +
                        listOf(".", ",", "?", "!", "'").map { Key(it, T.CHAR, 1.4f) } + listOf(Key("", T.SPACER, 0.5f), Key("⌫", T.DEL, 1.35f)),
                    listOf(Key("ABC", T.LAYER, 1.25f), Key("🌐", T.GLOBE, 1.1f), Key("espaço", T.SPACE, 4.8f), Key(enterLabel(), T.ENTER, 2.2f))
                )
            }
        }
        requestLayout(); invalidate()
    }

    private fun enterLabel(): String = when ((editorInfo?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION) {
        EditorInfo.IME_ACTION_SEARCH -> "pesquisar"
        EditorInfo.IME_ACTION_GO -> "ir"
        EditorInfo.IME_ACTION_SEND -> "enviar"
        EditorInfo.IME_ACTION_NEXT -> "seguinte"
        EditorInfo.IME_ACTION_DONE -> "OK"
        else -> "enter"
    }

    fun resetForField() { layer = Layer.ABC; buildRows(); refreshContext() }

    fun refreshContext() {
        val ic = service?.currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(64, 0)?.toString() ?: ""
        val auto = (editorInfo?.inputType ?: 0) and android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES != 0 || before.isEmpty()
        if (shift != 2) shift = if (auto && (before.isBlank() || before.trimEnd().endsWith(".") || before.trimEnd().endsWith("!") || before.trimEnd().endsWith("?")) && (before.isEmpty() || before.endsWith(" "))) 1 else 0
        val word = before.takeLastWhile { it.isLetter() }
        suggestions = suggest(word)
        invalidate()
    }

    private fun norm(s: String) = Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{M}"), "").lowercase()

    private fun suggest(word: String): List<String> {
        if (word.isEmpty()) return listOf("Olá", "Obrigado", "Sim")
        val w = norm(word)
        val found = Words.PT.filter { norm(it).startsWith(w) && it.lowercase() != word.lowercase() }.sortedBy { it.length }.take(2)
        val cap = word.first().isUpperCase()
        return (listOf("«$word»") + found.map { if (cap) it.replaceFirstChar { c -> c.uppercase() } else it }).take(3)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = sugH + 4 * keyH + 3 * rowGap + 14 * d
        setMeasuredDimension(w, h.toInt())
    }

    private fun layoutKeys() {
        val w = width.toFloat()
        var y = sugH + 4 * d
        for (row in rows) {
            val total = row.sumOf { it.weight.toDouble() }.toFloat()
            val unit = (w - hGap / 2) / total
            var x = hGap / 4
            for (k in row) {
                k.rect.set(x + hGap / 2, y, x + k.weight * unit - hGap / 2, y + keyH)
                x += k.weight * unit
            }
            y += keyH + rowGap
        }
        val sw = w / 3
        for (i in 0..2) sugRects[i].set(i * sw, 0f, (i + 1) * sw, sugH)
    }

    override fun onDraw(c: Canvas) {
        layoutKeys()
        val bg = if (dark) Color.rgb(43, 43, 45) else Color.rgb(209, 211, 217)
        val keyC = if (dark) Color.rgb(107, 107, 110) else Color.WHITE
        val spC = if (dark) Color.rgb(70, 70, 72) else Color.rgb(171, 176, 186)
        val shadow = if (dark) Color.rgb(28, 28, 30) else Color.rgb(137, 138, 141)
        val fg = if (dark) Color.WHITE else Color.BLACK
        c.drawColor(bg)

        // Sugestões
        text.textSize = 16 * d
        text.color = fg
        paint.color = if (dark) Color.rgb(85, 85, 88) else Color.rgb(180, 183, 190)
        for (i in 0..2) {
            val r = sugRects[i]
            val s = suggestions.getOrNull(i) ?: continue
            c.drawText(ellipsize(s, r.width() - 12 * d), r.centerX(), r.centerY() + 6 * d, text)
            if (i > 0) c.drawRect(r.left, r.top + 12 * d, r.left + d, r.bottom - 12 * d, paint)
        }

        val radius = 5 * d
        for (row in rows) for (k in row) {
            if (k.type == T.SPACER) continue
            val special = k.type !in setOf(T.CHAR, T.SPACE)
            val isPressed = pressed === k
            paint.color = shadow
            c.drawRoundRect(k.rect.left, k.rect.top + d, k.rect.right, k.rect.bottom + d, radius, radius, paint)
            paint.color = when {
                k.type == T.SHIFT && shift > 0 -> if (dark) Color.WHITE else Color.WHITE
                isPressed && special -> keyC
                isPressed -> spC
                special -> spC
                else -> keyC
            }
            c.drawRoundRect(k.rect, radius, radius, paint)
            text.color = if (k.type == T.SHIFT && shift > 0) Color.BLACK else fg
            when (k.type) {
                T.CHAR -> { text.textSize = 23 * d; c.drawText(if (layer == Layer.ABC && shift > 0) k.label.uppercase() else k.label, k.rect.centerX(), k.rect.centerY() + 8 * d, text) }
                T.SHIFT -> drawShift(c, k.rect, text.color)
                T.DEL -> drawDelete(c, k.rect, fg)
                else -> { text.textSize = 15.5f * d; c.drawText(k.label, k.rect.centerX(), k.rect.centerY() + 5.5f * d, text) }
            }
        }

        // Balão de pré-visualização / acentos
        val p = pressed
        if (p != null && p.type == T.CHAR) {
            val opts = accents ?: listOf(if (layer == Layer.ABC && shift > 0) p.label.uppercase() else p.label)
            val cw = 36 * d
            val total = cw * opts.size
            val left = (p.rect.centerX() - total / 2).coerceIn(2 * d, width - total - 2 * d)
            val top = p.rect.top - 58 * d
            paint.color = keyC
            paint.setShadowLayer(6 * d, 0f, 2 * d, Color.argb(70, 0, 0, 0))
            c.drawRoundRect(left - 4 * d, top, left + total + 4 * d, p.rect.top - 4 * d, 10 * d, 10 * d, paint)
            paint.clearShadowLayer()
            opts.forEachIndexed { i, s ->
                val cx = left + i * cw + cw / 2
                if (accents != null && i == accentSel) {
                    paint.color = Color.rgb(10, 132, 255)
                    c.drawRoundRect(left + i * cw + 2 * d, top + 4 * d, left + (i + 1) * cw - 2 * d, p.rect.top - 8 * d, 8 * d, 8 * d, paint)
                    text.color = Color.WHITE
                } else text.color = fg
                text.textSize = 28 * d
                c.drawText(s, cx, top + 38 * d, text)
            }
        }
    }

    private fun ellipsize(s: String, max: Float): String {
        if (text.measureText(s) <= max) return s
        var t = s
        while (t.length > 1 && text.measureText("$t…") > max) t = t.dropLast(1)
        return "$t…"
    }

    private fun drawShift(c: Canvas, r: RectF, color: Int) {
        val path = Path()
        val cx = r.centerX(); val cy = r.centerY(); val s = 9 * d
        path.moveTo(cx, cy - s); path.lineTo(cx + s, cy); path.lineTo(cx + s * 0.45f, cy)
        path.lineTo(cx + s * 0.45f, cy + s * 0.8f); path.lineTo(cx - s * 0.45f, cy + s * 0.8f)
        path.lineTo(cx - s * 0.45f, cy); path.lineTo(cx - s, cy); path.close()
        paint.color = color
        paint.style = if (shift > 0) Paint.Style.FILL else Paint.Style.STROKE
        paint.strokeWidth = 1.6f * d
        c.drawPath(path, paint)
        if (shift == 2) c.drawRect(cx - s * 0.45f, cy + s * 1.05f, cx + s * 0.45f, cy + s * 1.25f, paint)
        paint.style = Paint.Style.FILL
    }

    private fun drawDelete(c: Canvas, r: RectF, color: Int) {
        val cx = r.centerX(); val cy = r.centerY(); val w = 11 * d; val h = 8 * d
        val path = Path()
        path.moveTo(cx - w, cy); path.lineTo(cx - w * 0.45f, cy - h); path.lineTo(cx + w, cy - h)
        path.lineTo(cx + w, cy + h); path.lineTo(cx - w * 0.45f, cy + h); path.close()
        paint.color = color; paint.style = Paint.Style.STROKE; paint.strokeWidth = 1.6f * d
        c.drawPath(path, paint)
        c.drawLine(cx - 1 * d, cy - 3.5f * d, cx + 6 * d, cy + 3.5f * d, paint)
        c.drawLine(cx + 6 * d, cy - 3.5f * d, cx - 1 * d, cy + 3.5f * d, paint)
        paint.style = Paint.Style.FILL
    }

    private fun keyAt(x: Float, y: Float): Key? {
        for (row in rows) for (k in row) {
            if (k.type == T.SPACER) continue
            val r = k.rect
            if (x >= r.left - hGap / 2 && x <= r.right + hGap / 2 && y >= r.top - rowGap / 2 && y <= r.bottom + rowGap / 2) return k
        }
        return null
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (e.y < sugH) { pickSuggestion(e.x); return true }
                val k = keyAt(e.x, e.y) ?: return true
                pressed = k
                performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                if (k.type == T.CHAR && layer == Layer.ABC && accentMap.containsKey(k.label)) {
                    longPress = Runnable { accents = accentMap[k.label]!!.map { if (shift > 0) it.uppercase() else it }; accentSel = 0; invalidate() }
                    handler.postDelayed(longPress!!, 380)
                }
                if (k.type == T.DEL) {
                    deleteOne()
                    repeatDel = object : Runnable { override fun run() { deleteOne(); handler.postDelayed(this, 70) } }
                    handler.postDelayed(repeatDel!!, 420)
                }
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                val opts = accents
                val p = pressed
                if (opts != null && p != null) {
                    val cw = 36 * d
                    val left = (p.rect.centerX() - cw * opts.size / 2).coerceIn(2 * d, width - cw * opts.size - 2 * d)
                    accentSel = ((e.x - left) / cw).toInt().coerceIn(0, opts.size - 1)
                    invalidate()
                } else if (p != null && p.type == T.CHAR) {
                    val k = keyAt(e.x, e.y)
                    if (k != null && k !== p && k.type == T.CHAR) { pressed = k; longPress?.let { handler.removeCallbacks(it) }; invalidate() }
                }
            }
            MotionEvent.ACTION_UP -> {
                longPress?.let { handler.removeCallbacks(it) }
                repeatDel?.let { handler.removeCallbacks(it) }
                val k = pressed
                val acc = accents
                pressed = null; accents = null
                if (k != null) {
                    if (acc != null) commit(acc[accentSel]) else onKey(k)
                }
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                longPress?.let { handler.removeCallbacks(it) }
                repeatDel?.let { handler.removeCallbacks(it) }
                pressed = null; accents = null; invalidate()
            }
        }
        return true
    }

    private fun pickSuggestion(x: Float) {
        val i = (x / (width / 3f)).toInt().coerceIn(0, 2)
        val s = suggestions.getOrNull(i)?.replace("«", "")?.replace("»", "") ?: return
        val ic = service?.currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(64, 0)?.toString() ?: ""
        val word = before.takeLastWhile { it.isLetter() }
        ic.beginBatchEdit()
        if (word.isNotEmpty()) ic.deleteSurroundingText(word.length, 0)
        ic.commitText("$s ", 1)
        ic.endBatchEdit()
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    private fun commit(s: String) {
        val ic = service?.currentInputConnection ?: return
        ic.commitText(s, 1)
        if (shift == 1) shift = 0
        refreshContext()
    }

    private fun deleteOne() {
        val ic = service?.currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) ic.commitText("", 1)
        else {
            val before = ic.getTextBeforeCursor(2, 0)
            // Não parte emojis (pares substitutos) ao apagar
            val n = if (before != null && before.length == 2 && Character.isSurrogatePair(before[0], before[1])) 2 else 1
            ic.deleteSurroundingText(n, 0)
        }
        refreshContext()
    }

    private fun onKey(k: Key) {
        val ic = service?.currentInputConnection ?: return
        when (k.type) {
            T.CHAR -> commit(if (layer == Layer.ABC && shift > 0) k.label.uppercase() else k.label)
            T.SPACE -> {
                val now = System.currentTimeMillis()
                val before = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
                if (now - lastSpace < 450 && before.length == 2 && before[1] == ' ' && before[0].isLetterOrDigit()) {
                    ic.deleteSurroundingText(1, 0); ic.commitText(". ", 1)
                } else ic.commitText(" ", 1)
                lastSpace = now
                if (layer != Layer.ABC) { layer = Layer.ABC; buildRows() }
                refreshContext()
            }
            T.SHIFT -> {
                val now = System.currentTimeMillis()
                shift = if (now - lastShiftTap < 320) 2 else if (shift > 0) 0 else 1
                lastShiftTap = now
                invalidate()
            }
            T.DEL -> {}
            T.LAYER -> { layer = if (layer == Layer.ABC) Layer.NUM else Layer.ABC; buildRows() }
            T.SYMSWITCH -> { layer = if (layer == Layer.NUM) Layer.SYM else Layer.NUM; buildRows() }
            T.GLOBE -> service?.nextKeyboard()
            T.ENTER -> {
                val action = (editorInfo?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
                val noEnter = (editorInfo?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION != 0
                if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED && !noEnter) ic.performEditorAction(action)
                else {
                    ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
                    ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
                }
                refreshContext()
            }
            T.SPACER -> {}
        }
    }
}
