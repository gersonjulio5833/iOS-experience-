package com.iphoneexperience.launcher

import android.Manifest
import android.app.KeyguardManager
import android.app.NotificationManager
import android.bluetooth.BluetoothManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import android.view.inputmethod.InputMethodManager
import org.json.JSONObject

object SystemInfo {

    fun deviceSecure(c: Context) = (c.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isDeviceSecure

    fun notifAccess(c: Context): Boolean {
        val flat = Settings.Secure.getString(c.contentResolver, "enabled_notification_listeners") ?: return false
        return flat.split(":").any { ComponentName.unflattenFromString(it)?.packageName == c.packageName }
    }

    fun status(a: MainActivity): JSONObject {
        val c: Context = a
        val o = JSONObject()
        val cr = c.contentResolver
        try {
            val wm = c.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            o.put("wifi", wm.isWifiEnabled)
        } catch (_: Exception) {}
        try {
            val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            o.put("wifiConnected", caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true)
        } catch (_: Exception) {}
        try { o.put("mobileData", Settings.Global.getInt(cr, "mobile_data", 0) == 1) } catch (_: Exception) {}
        try {
            val bm = c.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
            o.put("bluetooth", bm.adapter?.isEnabled == true)
        } catch (_: Exception) {}
        o.put("airplane", Settings.Global.getInt(cr, Settings.Global.AIRPLANE_MODE_ON, 0) == 1)
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        o.put("dnd", nm.currentInterruptionFilter > NotificationManager.INTERRUPTION_FILTER_ALL)
        o.put("dndAccess", nm.isNotificationPolicyAccessGranted)
        o.put("writeSettings", Settings.System.canWrite(c))
        o.put("notifAccess", notifAccess(c))
        o.put("contactsPerm", c.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED)
        o.put("btPerm", android.os.Build.VERSION.SDK_INT < 31 || c.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED)
        o.put("postNotifPerm", android.os.Build.VERSION.SDK_INT < 33 || c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)
        o.put("overlayPerm", Settings.canDrawOverlays(c))
        o.put("a11yEnabled", OverlayService.instance != null)
        o.put("phonePerm", c.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED)
        try {
            val override = a.window.attributes.screenBrightness
            val sys = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128) / 255f
            o.put("brightness", if (override >= 0f) override.toDouble() else sys.toDouble())
            o.put("autoBrightness", Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, 0) == 1)
        } catch (_: Exception) {}
        val am = c.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        val max = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        o.put("volume", am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC).toDouble() / max)
        o.put("ringer", when (am.ringerMode) {
            android.media.AudioManager.RINGER_MODE_SILENT -> "silent"
            android.media.AudioManager.RINGER_MODE_VIBRATE -> "vibrate"
            else -> "normal"
        })
        o.put("rotationLock", Settings.System.getInt(cr, Settings.System.ACCELEROMETER_ROTATION, 1) == 0)
        o.put("torch", a.torchOn)
        c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.let { b ->
            val level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
            val scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
            val st = b.getIntExtra(BatteryManager.EXTRA_STATUS, 0)
            o.put("battery", level * 100 / scale)
            o.put("charging", st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL)
        }
        try {
            val tm = c.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            o.put("carrier", tm.networkOperatorName ?: "")
            if (Build.VERSION.SDK_INT >= 28) o.put("signal", tm.signalStrength?.level ?: 0)
        } catch (_: Exception) {}
        try {
            val home = c.packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), PackageManager.MATCH_DEFAULT_ONLY)
            o.put("defaultLauncher", home?.activityInfo?.packageName == c.packageName)
        } catch (_: Exception) {}
        o.put("deviceSecure", deviceSecure(c))
        o.put("night", (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES)
        try {
            val imm = c.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            o.put("imeEnabled", imm.enabledInputMethodList.any { it.packageName == c.packageName })
        } catch (_: Exception) {}
        return o
    }

    fun start(a: MainActivity, i: Intent): Boolean = try {
        a.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (_: Exception) { false }

    private fun first(a: MainActivity, vararg intents: Intent): Boolean = intents.any { start(a, it) }

    /** Abre o painel/ecrã oficial do Android correspondente. */
    fun openPanel(a: MainActivity, name: String) {
        val pkgUri = Uri.parse("package:" + a.packageName)
        val q = Build.VERSION.SDK_INT >= 29
        a.runOnUiThread {
            when (name) {
                "wifi" -> first(a, if (q) Intent(Settings.Panel.ACTION_WIFI) else Intent(Settings.ACTION_WIFI_SETTINGS), Intent(Settings.ACTION_WIFI_SETTINGS))
                "internet" -> first(a, if (q) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY) else Intent(Settings.ACTION_WIRELESS_SETTINGS), Intent(Settings.ACTION_WIRELESS_SETTINGS))
                "volume" -> first(a, if (q) Intent(Settings.Panel.ACTION_VOLUME) else Intent(Settings.ACTION_SOUND_SETTINGS), Intent(Settings.ACTION_SOUND_SETTINGS))
                "nfc" -> first(a, if (q) Intent(Settings.Panel.ACTION_NFC) else Intent(Settings.ACTION_NFC_SETTINGS), Intent(Settings.ACTION_NFC_SETTINGS), Intent(Settings.ACTION_WIRELESS_SETTINGS))
                "bluetooth" -> first(a, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                "airplane" -> first(a, Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS), Intent(Settings.ACTION_WIRELESS_SETTINGS))
                "mobile" -> first(a, Intent(Settings.ACTION_DATA_ROAMING_SETTINGS), Intent(Settings.ACTION_WIRELESS_SETTINGS))
                "dataUsage" -> first(a, Intent(Settings.ACTION_DATA_USAGE_SETTINGS), Intent(Settings.ACTION_WIRELESS_SETTINGS))
                "hotspot" -> first(a, Intent("android.settings.TETHER_SETTINGS"), Intent(Settings.ACTION_WIRELESS_SETTINGS))
                "location" -> first(a, Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                "home" -> first(a, Intent(Settings.ACTION_HOME_SETTINGS), Intent(Settings.ACTION_SETTINGS))
                "notifAccess" -> first(a, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                "policyAccess" -> first(a, Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                "writeSettings" -> first(a, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, pkgUri))
                "ime" -> first(a, Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
                "imePicker" -> (a.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
                "battery" -> first(a, Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS), Intent(Intent.ACTION_POWER_USAGE_SUMMARY))
                "cast" -> first(a, Intent(Settings.ACTION_CAST_SETTINGS))
                "display" -> first(a, Intent(Settings.ACTION_DISPLAY_SETTINGS))
                "sound" -> first(a, Intent(Settings.ACTION_SOUND_SETTINGS))
                "language" -> first(a, Intent(Settings.ACTION_LOCALE_SETTINGS))
                "notifications" -> first(a, Intent("android.settings.NOTIFICATION_SETTINGS"), Intent(Settings.ACTION_SETTINGS))
                "appSettings" -> first(a, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri))
                "accessibility" -> first(a, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                "wallpaper" -> first(a, Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), null))
                "camera" -> first(a, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA), Intent(MediaStore.ACTION_IMAGE_CAPTURE))
                "timer" -> first(a, Intent(AlarmClock.ACTION_SHOW_TIMERS), Intent(AlarmClock.ACTION_SET_TIMER), Intent(AlarmClock.ACTION_SHOW_ALARMS))
                "alarms" -> first(a, Intent(AlarmClock.ACTION_SHOW_ALARMS))
                "calculator" -> first(a, Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR))
                "dialer" -> {
                    var shown = false
                    if (a.callState != "idle" && a.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                        try { (a.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).showInCallScreen(false); shown = true } catch (_: Exception) {}
                    }
                    if (!shown) first(a, Intent(Intent.ACTION_DIAL))
                }
                else -> first(a, Intent(Settings.ACTION_SETTINGS))
            }
        }
    }
}
