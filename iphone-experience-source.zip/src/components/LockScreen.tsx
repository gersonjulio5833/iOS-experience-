import { useRef, useState } from "react";
import { useRT } from "@/lib/apps";
import { useStore, useL } from "@/lib/store";
import { wallSrc } from "@/lib/wallpapers";
import * as N from "@/lib/native";
import { useClock } from "./StatusBar";
import { Camera, Flashlight } from "./Glyphs";
import { NotificationStack } from "./NotificationCenter";

export default function LockScreen({ W, H, dark, onUnlocked }: { W: number; H: number; dark: boolean; onUnlocked: () => void }) {
  const L = useL();
  const s = useStore((x) => x.settings);
  const status = useRT((x) => x.status);
  const setRT = useRT((x) => x.set);
  const now = useClock();
  const ref = useRef<HTMLDivElement>(null);
  const g = useRef<any>({});
  const [leaving, setLeaving] = useState(false);
  const k = W / 393;

  const date = now.toLocaleDateString(s.lang === "en" ? "en-US" : "pt-PT", { weekday: "long", day: "numeric", month: "long" });
  const dateLabel = date.charAt(0).toUpperCase() + date.slice(1);
  const time = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;

  const apply = (dy: number, anim: boolean) => {
    const el = ref.current;
    if (!el) return;
    el.style.transition = anim ? `transform ${0.42 * s.animSpeed}s cubic-bezier(.25,.9,.3,1), opacity ${0.42 * s.animSpeed}s` : "none";
    el.style.transform = `translate3d(0,${Math.min(0, dy)}px,0)`;
    el.style.opacity = String(1 - Math.min(1, Math.max(0, -dy / H)) * 0.6);
  };

  const onDown = (e: React.PointerEvent) => {
    if ((e.target as HTMLElement).closest("[data-nocap]")) return;
    g.current = { y: e.clientY, t: Date.now(), on: true, pid: e.pointerId };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };
  const onMove = (e: React.PointerEvent) => {
    if (!g.current.on) return;
    apply(e.clientY - g.current.y, false);
  };
  const onUp = (e: React.PointerEvent) => {
    if (!g.current.on) return;
    g.current.on = false;
    const dy = e.clientY - g.current.y;
    const v = dy / Math.max(1, Date.now() - g.current.t);
    if (dy < -H * 0.18 || v < -0.6) unlock();
    else apply(0, true);
  };
  const unlock = () => {
    setLeaving(true);
    apply(-H, true);
    setTimeout(onUnlocked, 380 * s.animSpeed);
  };

  return (
    <div ref={ref} className="absolute inset-0 z-[45] overflow-hidden select-none" style={{ touchAction: "none" }}
      onPointerDown={onDown} onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onUp}>
      <img src={wallSrc(s.lockWallpaper, dark)} alt="" className="absolute inset-0 w-full h-full object-cover" draggable={false} />
      <div className="absolute inset-x-0 flex flex-col items-center" style={{ top: 62 * k }}>
        <div className="font-semibold" style={{ fontSize: 21 * k, color: "rgba(225,242,255,.85)", letterSpacing: "0.01em", textShadow: "0 1px 8px rgba(0,40,90,.18)" }}>{dateLabel}</div>
        <div className="leading-none tabular-nums"
          style={{ fontSize: 112 * k, marginTop: -2 * k, fontWeight: s.lockClock === "thin" ? 200 : 650, letterSpacing: s.lockClock === "thin" ? "-0.02em" : "-0.035em",
            color: "rgba(214,240,255,.9)", textShadow: "0 2px 18px rgba(0,50,120,.2)", fontFeatureSettings: '"tnum","ss01"' }}>
          {time}
        </div>
      </div>

      {s.notifOnLock && (
        <div className="absolute inset-x-0 overflow-y-auto no-scrollbar" style={{ bottom: 130 * k, maxHeight: H * 0.42, padding: "0 12px", touchAction: "pan-y" }} data-nocap>
          <NotificationStack locked dark={dark} compact />
        </div>
      )}

      <HoldButton style={{ left: 46 * k, bottom: 44 * k }} size={50 * k} active={status.torch}
        onActivate={async () => {
          const on = !useRT.getState().status.torch;
          const ok = await N.setTorch(on);
          setRT({ status: { ...useRT.getState().status, torch: ok ? on : false } });
        }}>
        <Flashlight size={22 * k} />
      </HoldButton>
      <HoldButton style={{ right: 46 * k, bottom: 44 * k }} size={50 * k}
        onActivate={() => { if (!N.openPanel("camera")) setRT({ toast: L("Câmara disponível no APK", "Camera available in the APK") }); }}>
        <Camera size={22 * k} />
      </HoldButton>

      {s.lockCaption && !leaving && (
        <div className="absolute inset-x-0 text-center text-white/60 pointer-events-none" style={{ bottom: 24 * k, fontSize: 10.5 * k }}>
          {L("Ecrã complementar · desliza para cima · a segurança Android mantém-se", "Companion screen · swipe up · Android security stays on")}
        </div>
      )}
      <div className="absolute left-1/2 -translate-x-1/2 rounded-full bg-white" style={{ bottom: 8 * k, width: 134 * k, height: 5 * k }} />
    </div>
  );
}

function HoldButton({ children, style, size, active, onActivate }: { children: React.ReactNode; style: React.CSSProperties; size: number; active?: boolean; onActivate: () => void }) {
  const [pressed, setPressed] = useState(false);
  const t = useRef<any>(null);
  return (
    <button data-nocap className="absolute rounded-full flex items-center justify-center transition-all duration-200"
      style={{ ...style, width: size, height: size, transform: pressed ? "scale(1.25)" : "scale(1)",
        background: active ? "rgba(255,255,255,.95)" : "rgba(0,0,0,.28)", color: active ? "#000" : "#fff",
        backdropFilter: "blur(20px) saturate(160%)", WebkitBackdropFilter: "blur(20px) saturate(160%)" }}
      onPointerDown={() => { setPressed(true); t.current = setTimeout(() => { N.haptic(20); onActivate(); setPressed(false); }, 380); }}
      onPointerUp={() => { clearTimeout(t.current); setPressed(false); }}
      onPointerLeave={() => { clearTimeout(t.current); setPressed(false); }}>
      {children}
    </button>
  );
}
