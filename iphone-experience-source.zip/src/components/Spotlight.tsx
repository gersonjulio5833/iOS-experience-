import { useEffect, useMemo, useRef, useState } from "react";
import { useRT, openApp } from "@/lib/apps";
import { useStore, useL } from "@/lib/store";
import * as N from "@/lib/native";
import { IconImage } from "./AppIcon";
import { Search, Close, Globe, Chevron } from "./Glyphs";
import { SETTINGS_INDEX } from "./Settings";

export default function Spotlight({ dark, onClose }: { dark: boolean; onClose: () => void }) {
  const L = useL();
  const apps = useRT((s) => s.apps);
  const counts = useStore((s) => s.launchCounts);
  const lang = useStore((s) => s.settings.lang);
  const [q, setQ] = useState("");
  const input = useRef<HTMLInputElement>(null);
  useEffect(() => { setTimeout(() => input.current?.focus(), 250); }, []);
  useEffect(() => N.onNative("back", onClose), [onClose]);

  const norm = (x: string) => x.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
  const list = useMemo(() => Object.values(apps), [apps]);
  const suggestions = useMemo(() => [...list].sort((a, b) => (counts[b.id] || 0) - (counts[a.id] || 0)).slice(0, 8), [list, counts]);
  const nq = norm(q.trim());
  const results = nq ? list.filter((a) => norm(a.label).includes(nq)).sort((a, b) => norm(a.label).indexOf(nq) - norm(b.label).indexOf(nq)) : [];
  const setResults = nq ? SETTINGS_INDEX.filter((e) => norm(lang === "en" ? e.en : e.pt).includes(nq)).slice(0, 5) : [];
  const fg = dark ? "#fff" : "#000";
  const card = dark ? "rgba(40,40,44,.6)" : "rgba(255,255,255,.55)";

  const launch = (id: string, el?: HTMLElement | null) => { onClose(); openApp(id, el?.getBoundingClientRect()); };

  return (
    <div className="absolute inset-0 z-[44] ios-fade-in" style={{ background: dark ? "rgba(0,0,0,.35)" : "rgba(255,255,255,.08)", backdropFilter: "blur(34px) saturate(160%)", WebkitBackdropFilter: "blur(34px) saturate(160%)" }}
      onPointerDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="absolute inset-x-0 top-[58px] px-4 ios-drop-in">
        <div className="flex items-center gap-2">
          <div className="flex-1 h-[40px] rounded-[12px] flex items-center gap-2 px-3" style={{ background: dark ? "rgba(118,118,128,.35)" : "rgba(255,255,255,.6)", color: fg }}>
            <Search size={16} className="opacity-60" />
            <input ref={input} value={q} onChange={(e) => setQ(e.target.value)} placeholder={L("Pesquisar", "Search")}
              onKeyDown={(e) => { if (e.key === "Enter") { if (results[0]) launch(results[0].id); else if (q.trim()) { N.webSearch(q); onClose(); } } }}
              className="flex-1 bg-transparent outline-none text-[17px] placeholder:opacity-60" style={{ color: fg }} />
            {q && <button onClick={() => setQ("")} className="w-[18px] h-[18px] rounded-full bg-gray-500/60 flex items-center justify-center text-white"><Close size={10} /></button>}
          </div>
          <button onClick={onClose} className="text-[17px] text-white font-medium" style={{ textShadow: "0 1px 3px rgba(0,0,0,.3)" }}>{L("Cancelar", "Cancel")}</button>
        </div>

        <div className="mt-4 overflow-y-auto no-scrollbar" style={{ maxHeight: "calc(100vh - 140px)", touchAction: "pan-y" }}>
          {!nq && (
            <>
              <div className="text-[13px] font-semibold text-white/85 mb-2 px-1">{L("Sugestões de apps", "Siri Suggestions")}</div>
              <div className="rounded-[18px] p-3 grid grid-cols-4 gap-y-3" style={{ background: card }}>
                {suggestions.map((a) => (
                  <button key={a.id} className="flex flex-col items-center gap-1" onClick={(e) => launch(a.id, e.currentTarget.firstElementChild as HTMLElement)}>
                    <IconImage app={a} size={56} /><span className="text-[11px] truncate max-w-[70px]" style={{ color: fg }}>{a.label}</span>
                  </button>
                ))}
              </div>
            </>
          )}
          {nq && (
            <div className="rounded-[18px] overflow-hidden" style={{ background: card, color: fg }}>
              {results.slice(0, 12).map((a, i) => (
                <button key={a.id} onClick={(e) => launch(a.id, e.currentTarget.firstElementChild as HTMLElement)} className="w-full flex items-center gap-3 px-3 py-2 active:bg-black/10" style={{ borderTop: i ? "0.5px solid rgba(128,128,128,.25)" : undefined }}>
                  <IconImage app={a} size={40} /><span className="text-[17px] text-left flex-1 truncate">{a.label}</span>
                </button>
              ))}
              {setResults.map((e) => (
                <button key={e.page + e.pt} onClick={() => { onClose(); useRT.getState().set({ overlay: "settings", settingsPage: e.page }); }} className="w-full flex items-center gap-3 px-3 py-2.5 active:bg-black/10" style={{ borderTop: "0.5px solid rgba(128,128,128,.25)" }}>
                  <span className="w-10 h-10 ios-squircle overflow-hidden"><svg viewBox="0 0 100 100"><rect width="100" height="100" fill="#8E8E93" /></svg></span>
                  <span className="text-[17px] text-left flex-1">{lang === "en" ? e.en : e.pt}<span className="block text-[13px] opacity-60">{L("Ajustes", "Settings")}</span></span>
                  <Chevron size={14} className="opacity-40" />
                </button>
              ))}
              <button onClick={() => { N.webSearch(q); onClose(); }} className="w-full flex items-center gap-3 px-3 py-3 active:bg-black/10" style={{ borderTop: results.length || setResults.length ? "0.5px solid rgba(128,128,128,.25)" : undefined }}>
                <span className="w-10 h-10 rounded-full bg-[#0A84FF] flex items-center justify-center text-white"><Globe size={22} /></span>
                <span className="text-[17px] text-left">{L("Pesquisar na web", "Search Web")} «{q}»</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
