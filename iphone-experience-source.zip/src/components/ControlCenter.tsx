import { useEffect, useRef, useState } from "react";
import { useRT, toast } from "@/lib/apps";
import { useStore, useL } from "@/lib/store";
import * as N from "@/lib/native";
import { MediaArt } from "./DynamicIsland";
import * as I from "./Glyphs";

type Status = N.SystemStatus;

export default function ControlCenter({ W, H, dark, onClose }: { W: number; H: number; dark: boolean; onClose: () => void }) {
  const L = useL();
  const s = useStore((x) => x.settings);
  const setS = useStore((x) => x.set);
  const st = useRT((x) => x.status);
  const media = useRT((x) => x.media);
  const setRT = useRT((x) => x.set);
  const ref = useRef<HTMLDivElement>(null);
  const scroller = useRef<HTMLDivElement>(null);
  const g = useRef<any>({});
  const [closing, setClosing] = useState(false);

  const k = Math.min(W / 393, 1.15);
  const u = 66 * k, gap = 14 * k;
  const gridW = 4 * u + 3 * gap;
  const left = (W - gridW) / 2;
  const at = (col: number, row: number, cs = 1, rs = 1): React.CSSProperties => ({
    position: "absolute", left: left + col * (u + gap), top: 127 * k + row * (u + gap), width: cs * u + (cs - 1) * gap, height: rs * u + (rs - 1) * gap,
  });
  const patch = (p: Partial<Status>) => setRT({ status: { ...useRT.getState().status, ...p } });

  const close = () => {
    setClosing(true);
    setTimeout(onClose, 260 * s.animSpeed);
  };
  useEffect(() => N.onNative("back", close), []); // eslint-disable-line

  const modBg = dark || true ? "rgba(30,30,32,.42)" : "rgba(255,255,255,.3)";
  const circle = (active: boolean, activeBg = "#0A84FF"): React.CSSProperties => ({
    background: active ? activeBg : "rgba(28,28,30,.5)", color: "#fff",
  });

  const needWrite = () => toast(L("Concede «Modificar definições do sistema» em Ajustes › Permissões", "Grant “Modify system settings” in Settings › Permissions"));

  const shortcuts: Record<string, { icon: React.ReactNode; active?: boolean; run: () => void; label: string }> = {
    darkmode: { icon: <I.Contrast size={30 * k} />, label: L("Modo escuro", "Dark Mode"), active: dark, run: () => setS({ theme: dark ? "light" : "dark" }) },
    calculator: { icon: <I.Calculator size={30 * k} />, label: L("Calculadora", "Calculator"), run: () => go("calculator") },
    battery: { icon: <I.Battery size={32 * k} level={st.battery} charging={st.charging} />, label: L("Poupança de bateria", "Battery Saver"), run: () => go("battery") },
    cast: { icon: <I.Mirror size={28 * k} />, label: L("Transmitir ecrã", "Screen Mirroring"), run: () => go("cast") },
    timer: { icon: <I.Timer size={28 * k} />, label: L("Temporizador", "Timer"), run: () => go("timer") },
    alarm: { icon: <I.Alarm size={28 * k} />, label: L("Alarme", "Alarm"), run: () => go("alarms") },
    camera: { icon: <I.Camera size={28 * k} />, label: L("Câmara", "Camera"), run: () => go("camera") },
    flashlight: {
      icon: <I.Flashlight size={26 * k} />, label: L("Lanterna", "Flashlight"), active: st.torch,
      run: async () => { const on = !st.torch; const ok = await N.setTorch(on); patch({ torch: ok ? on : false }); if (!ok) toast(L("Lanterna indisponível", "Flashlight unavailable")); },
    },
    hotspot: { icon: <I.Hotspot size={26 * k} />, label: L("Ponto de acesso", "Hotspot"), run: () => go("hotspot") },
    location: { icon: <I.Location size={24 * k} />, label: L("Localização", "Location"), run: () => go("location") },
    nfc: { icon: <I.Nfc size={26 * k} />, label: "NFC", run: () => go("nfc") },
    dataUsage: { icon: <I.DataUsage size={26 * k} />, label: L("Dados móveis", "Data Usage"), run: () => go("dataUsage") },
  };

  function go(p: N.PanelName) {
    if (!N.openPanel(p)) toast(L("Disponível apenas no APK Android", "Available only in the Android APK"));
    else if (!["wifi", "internet", "volume", "nfc"].includes(p)) close();
  }

  const items = s.ccShortcuts.filter((x) => shortcuts[x]);
  const lastRow = 4 + Math.ceil(items.length / 4);

  return (
    <div ref={ref} className={"absolute inset-0 z-[44] " + (closing ? "ios-cc-out" : "ios-cc-in")} style={{ touchAction: "none" }}
      onPointerDown={(e) => { if ((e.target as HTMLElement).closest("[data-nocap]")) return; g.current = { y: e.clientY, x: e.clientX, on: true }; }}
      onPointerUp={(e) => { if (!g.current.on) return; g.current.on = false; const dy = e.clientY - g.current.y; if (dy < -50 || (Math.abs(dy) < 6 && Math.abs(e.clientX - g.current.x) < 6)) close(); }}>
      <div className="absolute inset-0" style={{ background: "rgba(0,0,0,.26)", backdropFilter: `blur(${Math.max(20, s.blur)}px) saturate(130%)`, WebkitBackdropFilter: `blur(${Math.max(20, s.blur)}px) saturate(130%)` }} />
      <div ref={scroller} className="absolute inset-0 overflow-y-auto no-scrollbar" style={{ touchAction: "pan-y" }}>
        <div className="relative text-white" style={{ height: Math.max(H, 127 * k + lastRow * (u + gap) + 40) }}>
          {/* topo */}
          <button data-nocap onClick={() => { setRT({ overlay: "settings", settingsPage: "controlcenter" }); }} className="absolute opacity-90" style={{ left: 40 * k, top: 26 * k }}><I.Plus size={20 * k} /></button>
          <button data-nocap onClick={() => { close(); setTimeout(() => setRT({ locked: true }), 200); }} className="absolute opacity-90" style={{ right: 40 * k, top: 26 * k }}><I.Power size={20 * k} /></button>
          <div className="absolute flex items-center justify-between" style={{ left: left + 2, right: left + 2, top: 74 * k, fontSize: 16 * k }}>
            <span className="flex items-center gap-1.5 font-medium">
              <I.Cellular size={16 * k} className={st.signal ? "" : "opacity-40"} />{st.carrier || (st.airplane ? L("Modo de voo", "Airplane") : L("Rede", "Network"))}{st.wifiConnected && <I.Wifi size={16 * k} />}
            </span>
            <span className="flex items-center gap-1.5 font-medium">{st.rotationLock && <I.RotationLock size={15 * k} />}{st.battery}% <I.Battery size={26 * k} level={st.battery} charging={st.charging} /></span>
          </div>

          {/* conectividade */}
          <div data-nocap className="cc-mod" style={{ ...at(0, 0, 2, 2), borderRadius: 34 * k, background: modBg }}>
            <div className="absolute grid grid-cols-2" style={{ inset: 13 * k, gap: 10 * k }}>
              <CBtn style={circle(st.airplane, "#FF9F0A")} onClick={() => go("airplane")}><I.Airplane size={24 * k} /></CBtn>
              <CBtn style={circle(st.mobileData, "#34C759")} onClick={() => go("internet")}><I.Antenna size={24 * k} /></CBtn>
              <CBtn style={circle(st.wifi)} onClick={() => go("wifi")}><I.Wifi size={24 * k} /></CBtn>
              <div className="grid grid-cols-2 place-items-center" style={{ gap: 4 * k }}>
                <CBtn small style={circle(false)} onClick={() => go("dataUsage")}><I.Cellular size={12 * k} /></CBtn>
                <CBtn small style={circle(st.bluetooth)} onClick={() => go("bluetooth")}><I.Bluetooth size={13 * k} /></CBtn>
                <CBtn small style={circle(false)} onClick={() => go("hotspot")}><I.Link size={13 * k} /></CBtn>
                <CBtn small style={circle(false)} onClick={() => go("nfc")}><I.Nfc size={13 * k} /></CBtn>
              </div>
            </div>
          </div>

          {/* multimédia */}
          <div data-nocap className="cc-mod overflow-hidden" style={{ ...at(2, 0, 2, 2), borderRadius: 34 * k, background: modBg, padding: 14 * k }}>
            <div className="flex justify-between items-start">
              {media ? <MediaArt m={media} size={58 * k} radius={12 * k} /> : <div style={{ width: 58 * k, height: 58 * k, borderRadius: 12 * k, background: "rgba(255,255,255,.15)" }} className="flex items-center justify-center"><I.Note size={24 * k} className="opacity-60" /></div>}
              <button onClick={() => go("volume")} className="rounded-full flex items-center justify-center" style={{ width: 34 * k, height: 34 * k, background: "rgba(255,255,255,.15)" }}><I.AirPlay size={18 * k} /></button>
            </div>
            <div className="mt-2 overflow-hidden whitespace-nowrap font-semibold" style={{ fontSize: 16 * k }}>
              <span className={media && media.title.length > 14 ? "ios-marquee inline-block" : ""}>{media ? media.title : L("Sem reprodução", "Not Playing")}</span>
            </div>
            <div className="truncate" style={{ fontSize: 15 * k, color: media ? "#9ee6a8" : "rgba(255,255,255,.55)" }}>
              {media ? (media.demo ? "DEMO · " : "") + (media.artist || media.appLabel || "") : L("Abre uma app de música", "Open a music app")}
            </div>
            <div className="flex justify-around items-center mt-1.5">
              <button onClick={() => N.mediaAction("prev")} className="active:scale-90"><I.Prev size={24 * k} /></button>
              <button onClick={() => N.mediaAction("toggle")} className="active:scale-90">{media?.playing ? <I.Pause size={26 * k} /> : <I.Play size={26 * k} />}</button>
              <button onClick={() => N.mediaAction("next")} className="active:scale-90"><I.Next size={24 * k} /></button>
            </div>
          </div>

          {/* rotação e silêncio */}
          <div data-nocap style={at(0, 2)}><CBtn style={{ ...circle(st.rotationLock, "#fff"), color: st.rotationLock ? "#FF3B30" : "#fff" }}
            onClick={() => { const v = !st.rotationLock; if (N.setRotationLock(v)) patch({ rotationLock: v }); else if (N.isNative) needWrite(); else toast(L("Disponível no APK", "Available in the APK")); }}><I.RotationLock size={30 * k} /></CBtn></div>
          <div data-nocap style={at(1, 2)}><CBtn style={{ ...circle(st.ringer === "silent", "#fff"), color: st.ringer === "silent" ? "#FF3B30" : "#fff" }}
            onClick={() => { const m = st.ringer === "silent" ? "normal" : "silent"; if (N.setRinger(m)) patch({ ringer: m }); else if (N.isNative) { toast(L("Concede acesso «Não incomodar»", "Grant Do Not Disturb access")); N.openPanel("policyAccess"); } else toast(L("Disponível no APK", "Available in the APK")); }}>
            {st.ringer === "silent" ? <I.BellSlash size={28 * k} /> : <I.Bell size={28 * k} />}</CBtn></div>

          {/* controlos verticais */}
          <div data-nocap style={at(2, 2, 1, 2)}>
            <VSlider value={st.brightness} radius={28 * k} icon={<I.Sun size={26 * k} style={{ color: "#FFB800" }} />}
              onChange={(v) => { patch({ brightness: v }); const ok = N.setBrightness(v); if (!ok && N.isNative && !g.current.warned) { g.current.warned = true; needWrite(); } }} />
          </div>
          <div data-nocap style={at(3, 2, 1, 2)}>
            <VSlider value={st.volume} radius={28 * k} icon={<I.Speaker size={24 * k} style={{ color: "#0A84FF" }} />} onChange={(v) => { patch({ volume: v }); N.setVolume(v); }} />
          </div>

          {/* Foco / Não incomodar */}
          <button data-nocap className="cc-mod flex items-center text-left" style={{ ...at(0, 3, 2, 1), borderRadius: 34 * k, padding: 8 * k, background: st.dnd ? "rgba(255,255,255,.92)" : modBg, color: st.dnd ? "#000" : "#fff" }}
            onClick={() => { const v = !st.dnd; if (N.setDnd(v)) patch({ dnd: v }); else if (N.isNative) { toast(L("Concede acesso «Não incomodar» ao Launcher", "Grant Do Not Disturb access")); N.openPanel("policyAccess"); } else toast(L("Disponível no APK", "Available in the APK")); }}>
            <span className="rounded-full flex items-center justify-center shrink-0" style={{ width: 50 * k, height: 50 * k, background: st.dnd ? "#5E5CE6" : "linear-gradient(135deg,#d9622b,#a8401b)", color: "#fff" }}><I.Moon size={24 * k} /></span>
            <span className="ml-3 font-semibold leading-tight" style={{ fontSize: 16 * k }}>{L("Foco", "Focus")}<span className="block font-normal opacity-70" style={{ fontSize: 13 * k }}>{st.dnd ? L("Não incomodar", "Do Not Disturb") : L("Desligado", "Off")}</span></span>
          </button>

          {/* atalhos */}
          {items.map((key, i) => {
            const sc = shortcuts[key];
            return (
              <div data-nocap key={key} style={at(i % 4, 4 + Math.floor(i / 4))}>
                <CBtn label={sc.label} style={{ ...circle(!!sc.active, "#fff"), color: sc.active ? "#000" : "#fff" }} onClick={sc.run}>{sc.icon}</CBtn>
              </div>
            );
          })}

          {/* indicadores laterais */}
          <div className="absolute flex flex-col items-center text-white" style={{ right: 12 * k, top: 345 * k, gap: 22 * k }}>
            <I.Heart size={18 * k} />
            <button data-nocap onClick={() => scroller.current?.scrollTo({ top: 0, behavior: "smooth" })}><I.Note size={18 * k} className="opacity-50" /></button>
            <button data-nocap onClick={() => go("home")}><I.Home size={18 * k} className="opacity-50" /></button>
            <button data-nocap onClick={() => go("internet")}><I.Antenna size={18 * k} className="opacity-50" /></button>
          </div>
        </div>
      </div>
      <div className="absolute left-1/2 -translate-x-1/2 rounded-full bg-white pointer-events-none" style={{ bottom: 8, width: 134 * k, height: 5 * k }} />
    </div>
  );
}

function CBtn({ children, style, onClick, small, label }: { children: React.ReactNode; style: React.CSSProperties; onClick: () => void; small?: boolean; label?: string }) {
  return (
    <button aria-label={label} onClick={onClick} className="rounded-full flex items-center justify-center active:scale-[.92] transition-[transform,background] duration-150"
      style={{ width: small ? "86%" : "100%", aspectRatio: "1", ...style }}>
      {children}
    </button>
  );
}

function VSlider({ value, onChange, icon, radius }: { value: number; onChange: (v: number) => void; icon: React.ReactNode; radius: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const g = useRef<any>({});
  const [v, setV] = useState(value);
  const [active, setActive] = useState(false);
  useEffect(() => { if (!g.current.on) setV(value); }, [value]);
  const raf = useRef(0);
  return (
    <div ref={ref} className="relative w-full h-full overflow-hidden transition-transform duration-200"
      style={{ borderRadius: radius, background: "rgba(28,28,30,.5)", touchAction: "none", transform: active ? "scaleX(1.06) scaleY(1.03)" : undefined }}
      onPointerDown={(e) => { (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId); g.current = { on: true, y: e.clientY, v0: v }; setActive(true); }}
      onPointerMove={(e) => {
        if (!g.current.on) return;
        const h = ref.current!.clientHeight;
        const nv = Math.max(0, Math.min(1, g.current.v0 - (e.clientY - g.current.y) / h));
        setV(nv);
        cancelAnimationFrame(raf.current);
        raf.current = requestAnimationFrame(() => onChange(nv));
      }}
      onPointerUp={() => { g.current.on = false; setActive(false); }}
      onPointerCancel={() => { g.current.on = false; setActive(false); }}>
      <div className="absolute inset-x-0 bottom-0 bg-white" style={{ height: `${v * 100}%` }} />
      <div className="absolute inset-x-0 flex justify-center" style={{ bottom: "13%" }}>{icon}</div>
    </div>
  );
}
