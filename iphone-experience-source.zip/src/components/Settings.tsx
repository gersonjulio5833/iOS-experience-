import { useEffect, useRef, useState, type ReactNode } from "react";
import { useRT, loadApps, toast } from "@/lib/apps";
import { useStore, useL, ALL_CC_SHORTCUTS, defaultSettings } from "@/lib/store";
import { WALLPAPERS, wallSrc } from "@/lib/wallpapers";
import * as N from "@/lib/native";
import * as I from "./Glyphs";
import IosKeyboard from "./IosKeyboard";

export const SETTINGS_INDEX: { page: string; pt: string; en: string }[] = [
  { page: "profile", pt: "Perfil e personalização", en: "Profile & personalization" },
  { page: "wallpaper", pt: "Papel de parede", en: "Wallpaper" },
  { page: "homescreen", pt: "Ecrã principal e tamanho dos ícones", en: "Home Screen & icon size" },
  { page: "dock", pt: "Dock e pastas", en: "Dock & folders" },
  { page: "animations", pt: "Animações", en: "Animations" },
  { page: "transparency", pt: "Transparência e desfoque", en: "Transparency & blur" },
  { page: "display", pt: "Ecrã e brilho · modo claro/escuro", en: "Display & Brightness · light/dark" },
  { page: "language", pt: "Idioma", en: "Language" },
  { page: "notifications", pt: "Notificações", en: "Notifications" },
  { page: "island", pt: "Dynamic Island", en: "Dynamic Island" },
  { page: "lock", pt: "Ecrã de bloqueio", en: "Lock Screen" },
  { page: "controlcenter", pt: "Centro de controlo", en: "Control Center" },
  { page: "keyboard", pt: "Teclado", en: "Keyboard" },
  { page: "permissions", pt: "Permissões", en: "Permissions" },
  { page: "about", pt: "Sobre e estado das funcionalidades", en: "About & feature status" },
  { page: "general", pt: "Geral", en: "General" },
];

const ICON_COLORS: Record<string, string> = {
  orange: "#FF9500", blue: "#007AFF", green: "#34C759", red: "#FF3B30", pink: "#FF2D55", indigo: "#5856D6", gray: "#8E8E93", cyan: "#32ADE6", teal: "#30B0C7", purple: "#AF52DE", yellow: "#FFCC00", black: "#1c1c1e",
};

export default function Settings({ dark, onClose }: { dark: boolean; onClose: () => void }) {
  const L = useL();
  const initial = useRT((s) => s.settingsPage);
  const [stack, setStack] = useState<string[]>(initial ? ["root", initial] : ["root"]);
  const [dir, setDir] = useState<"push" | "pop">("push");
  const page = stack[stack.length - 1];
  const push = (p: string) => { setDir("push"); setStack((s) => [...s, p]); };
  const pop = () => { setDir("pop"); setStack((s) => (s.length > 1 ? s.slice(0, -1) : s)); };
  const stackRef = useRef(stack); stackRef.current = stack;
  useEffect(() => N.onNative("back", () => (stackRef.current.length > 1 ? pop() : onClose())), [onClose]); // eslint-disable-line
  useEffect(() => N.onNative("home", onClose), [onClose]);

  const C = {
    bg: dark ? "#000" : "#f2f2f7", cell: dark ? "#1c1c1e" : "#fff", fg: dark ? "#fff" : "#000", sub: dark ? "#ebebf599" : "#3c3c4399",
    sep: dark ? "#38383a" : "#c6c6c8", blue: dark ? "#0A84FF" : "#007AFF",
  };
  const titles: Record<string, string> = Object.fromEntries(SETTINGS_INDEX.map((e) => [e.page, L(e.pt, e.en).split(" · ")[0]]));
  titles.root = L("Ajustes", "Settings");
  titles.homescreen = L("Ecrã principal", "Home Screen");
  titles.about = L("Sobre", "About");
  titles.profile = L("Perfil", "Profile");

  return (
    <div className="absolute inset-0 z-[46] ios-app-open overflow-hidden" style={{ background: C.bg, color: C.fg }}>
      <div key={page} className={"absolute inset-0 overflow-y-auto no-scrollbar " + (dir === "push" ? "ios-push" : "ios-pop-back")} style={{ touchAction: "pan-y" }}>
        <div className="sticky top-0 z-10 flex items-center justify-between px-2" style={{ height: 96, paddingTop: 44, background: dark ? "rgba(0,0,0,.82)" : "rgba(242,242,247,.82)", backdropFilter: "blur(20px)" }}>
          {stack.length > 1 ? (
            <button onClick={pop} className="flex items-center text-[17px]" style={{ color: C.blue }}><I.Back size={22} />{titles[stack[stack.length - 2]] ?? L("Voltar", "Back")}</button>
          ) : <span />}
          {stack.length > 1 && <span className="absolute left-1/2 -translate-x-1/2 text-[17px] font-semibold truncate max-w-[50%]">{titles[page]}</span>}
          <button onClick={onClose} className="text-[17px] font-semibold pr-2" style={{ color: C.blue }}>{L("Fechar", "Close")}</button>
        </div>
        <div className="px-4 pb-16">
          {stack.length === 1 && <h1 className="text-[34px] font-bold -mt-1 mb-2">{titles.root}</h1>}
          <Pages page={page} push={push} C={C} dark={dark} />
        </div>
      </div>
    </div>
  );
}

type Col = { bg: string; cell: string; fg: string; sub: string; sep: string; blue: string };

function Group({ children, C, header, footer }: { children: ReactNode; C: Col; header?: string; footer?: string }) {
  return (
    <div className="mt-6">
      {header && <div className="uppercase text-[13px] px-4 mb-1.5" style={{ color: C.sub }}>{header}</div>}
      <div className="rounded-[10px] overflow-hidden ios-group" style={{ background: C.cell, ["--sep" as any]: C.sep }}>{children}</div>
      {footer && <div className="text-[13px] px-4 mt-1.5 leading-snug" style={{ color: C.sub }}>{footer}</div>}
    </div>
  );
}

function Row({ C, icon, color, label, value, onClick, chevron = true, external, right, sub, danger }: { C: Col; icon?: ReactNode; color?: string; label: string; value?: string; onClick?: () => void; chevron?: boolean; external?: boolean; right?: ReactNode; sub?: string; danger?: boolean }) {
  return (
    <button onClick={onClick} className="ios-row w-full flex items-center min-h-[44px] text-left active:bg-gray-500/20 pl-4" disabled={!onClick && !right}>
      {icon && <span className="w-[29px] h-[29px] rounded-[7px] flex items-center justify-center text-white mr-3 shrink-0" style={{ background: ICON_COLORS[color || "gray"] }}>{icon}</span>}
      <span className="ios-row-inner flex-1 flex items-center min-h-[44px] pr-4 py-2">
        <span className="flex-1 min-w-0">
          <span className="block text-[17px] truncate" style={{ color: danger ? "#FF3B30" : C.fg }}>{label}</span>
          {sub && <span className="block text-[13px] leading-snug" style={{ color: C.sub }}>{sub}</span>}
        </span>
        {value && <span className="text-[17px] mr-1.5 shrink-0" style={{ color: C.sub }}>{value}</span>}
        {right}
        {!right && external && <I.External size={15} style={{ color: C.sub }} />}
        {!right && !external && chevron && onClick && <I.Chevron size={14} style={{ color: C.sub, opacity: 0.7 }} />}
      </span>
    </button>
  );
}

function Toggle({ on, onChange }: { on: boolean; onChange: (v: boolean) => void }) {
  return (
    <span role="switch" aria-checked={on} onClick={(e) => { e.stopPropagation(); onChange(!on); }}
      className="relative inline-block w-[51px] h-[31px] rounded-full transition-colors duration-200 shrink-0" style={{ background: on ? "#34C759" : "rgba(120,120,128,.32)" }}>
      <span className="absolute top-[2px] w-[27px] h-[27px] rounded-full bg-white transition-all duration-200" style={{ left: on ? 22 : 2, boxShadow: "0 3px 8px rgba(0,0,0,.15), 0 1px 1px rgba(0,0,0,.16)" }} />
    </span>
  );
}

function Slider({ value, min, max, step = 0.01, onChange, C, left, right }: { value: number; min: number; max: number; step?: number; onChange: (v: number) => void; C: Col; left?: ReactNode; right?: ReactNode }) {
  return (
    <div className="flex items-center gap-3 px-4 py-3" style={{ color: C.sub }}>
      {left}
      <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(+e.target.value)} className="ios-range flex-1"
        style={{ ["--p" as any]: `${((value - min) / (max - min)) * 100}%` }} />
      {right}
    </div>
  );
}

function Segmented<T extends string | number>({ value, options, onChange, dark }: { value: T; options: [T, string][]; onChange: (v: T) => void; dark: boolean }) {
  return (
    <div className="flex p-[2px] rounded-[9px] mx-4 my-3" style={{ background: dark ? "rgba(118,118,128,.24)" : "rgba(118,118,128,.12)" }}>
      {options.map(([v, l]) => (
        <button key={String(v)} onClick={() => onChange(v)} className="flex-1 h-[28px] rounded-[7px] text-[13px] font-medium transition-all"
          style={v === value ? { background: dark ? "#636366" : "#fff", boxShadow: "0 3px 8px rgba(0,0,0,.12)" } : undefined}>{l}</button>
      ))}
    </div>
  );
}

function Check({ C, label, on, onClick, sub }: { C: Col; label: string; on: boolean; onClick: () => void; sub?: string }) {
  return <Row C={C} label={label} sub={sub} onClick={onClick} right={on ? <span style={{ color: C.blue }} className="text-[17px] font-semibold">✓</span> : <span />} />;
}

function Pages({ page, push, C, dark }: { page: string; push: (p: string) => void; C: Col; dark: boolean }) {
  const L = useL();
  const s = useStore((x) => x.settings);
  const set = useStore((x) => x.set);
  const st = useRT((x) => x.status);
  const setRT = useRT((x) => x.set);
  const [q, setQ] = useState("");
  const [kbText, setKbText] = useState("");
  const onOff = (v: boolean) => (v ? L("Ligado", "On") : L("Desligado", "Off"));
  const sys = (p: N.PanelName) => { if (!N.openPanel(p)) toast(L("Abre as definições reais do Android no APK", "Opens real Android settings in the APK")); };
  const nativeOnly = !N.isNative ? L("No navegador apenas é guardada a preferência.", "In the browser only the preference is saved.") : undefined;

  switch (page) {
    case "root": {
      const nq = q.trim().toLowerCase();
      return (
        <>
          <div className="h-9 rounded-[10px] flex items-center gap-2 px-2.5" style={{ background: dark ? "rgba(118,118,128,.24)" : "rgba(118,118,128,.12)" }}>
            <I.Search size={15} style={{ color: C.sub }} />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={L("Pesquisar", "Search")} className="flex-1 bg-transparent outline-none text-[17px]" style={{ color: C.fg }} />
          </div>
          {nq ? (
            <Group C={C}>
              {SETTINGS_INDEX.filter((e) => L(e.pt, e.en).toLowerCase().includes(nq)).map((e) => <Row key={e.page} C={C} label={L(e.pt, e.en)} onClick={() => push(e.page)} />)}
            </Group>
          ) : (
            <>
              <Group C={C}>
                <button onClick={() => push("profile")} className="w-full flex items-center gap-3.5 px-4 py-3 text-left active:bg-gray-500/20">
                  <span className="w-[60px] h-[60px] rounded-full flex items-center justify-center text-white text-[24px] font-semibold" style={{ background: "linear-gradient(135deg,#a1a1aa,#6b7280)" }}>
                    {(s.profileName || "U").split(" ").map((w) => w[0]).slice(0, 2).join("").toUpperCase()}
                  </span>
                  <span className="flex-1"><span className="block text-[20px] font-medium">{s.profileName || L("O teu nome", "Your Name")}</span><span className="block text-[13px]" style={{ color: C.sub }}>{L("Perfil, personalização e privacidade", "Profile, personalization & privacy")}</span></span>
                  <I.Chevron size={14} style={{ color: C.sub }} />
                </button>
              </Group>
              {!N.isNative && (
                <Group C={C} header={L("Instalar no Android", "Install on Android")} footer={L("APK compilado e verificado (Android 8–14, alvo Android 13). Instruções completas em LEIA-ME.md no código-fonte.", "Compiled and verified APK (Android 8–14, targets Android 13). Full instructions in LEIA-ME.md in the source.")}>
                  <Row C={C} icon={<I.Home size={18} />} color="green" label={L("Transferir APK", "Download APK")} sub="iPhoneExperience.apk" onClick={() => window.open("./iPhoneExperience.apk", "_blank")} external />
                  <Row C={C} icon={<I.Grid size={16} />} color="gray" label={L("Transferir código-fonte", "Download source code")} sub="iphone-experience-source.zip" onClick={() => window.open("./iphone-experience-source.zip", "_blank")} external />
                </Group>
              )}
              {N.isNative && !st.defaultLauncher && (
                <Group C={C} footer={L("Necessário para que o botão Início abra este Launcher.", "Required so the Home button opens this launcher.")}>
                  <Row C={C} icon={<I.Home size={18} />} color="blue" label={L("Definir como Launcher predefinido", "Set as default launcher")} onClick={() => sys("home")} external />
                </Group>
              )}
              <Group C={C}>
                <Row C={C} icon={<I.Airplane size={18} />} color="orange" label={L("Modo de voo", "Airplane Mode")} value={onOff(st.airplane)} onClick={() => sys("airplane")} external />
                <Row C={C} icon={<I.Wifi size={18} />} color="blue" label="Wi-Fi" value={st.wifiConnected ? L("Ligado", "Connected") : onOff(st.wifi)} onClick={() => sys("wifi")} external />
                <Row C={C} icon={<I.Bluetooth size={18} />} color="blue" label="Bluetooth" value={onOff(st.bluetooth)} onClick={() => sys("bluetooth")} external />
                <Row C={C} icon={<I.Antenna size={18} />} color="green" label={L("Rede móvel", "Cellular")} value={st.carrier || undefined} onClick={() => sys("mobile")} external />
                <Row C={C} icon={<I.Hotspot size={18} />} color="green" label={L("Ponto de acesso pessoal", "Personal Hotspot")} onClick={() => sys("hotspot")} external />
              </Group>
              <Group C={C}>
                <Row C={C} icon={<I.Bell size={18} />} color="red" label={L("Notificações", "Notifications")} onClick={() => push("notifications")} />
                <Row C={C} icon={<I.Speaker size={18} />} color="pink" label={L("Sons e vibração", "Sounds & Haptics")} onClick={() => sys("sound")} external />
                <Row C={C} icon={<I.Moon size={18} />} color="indigo" label={L("Foco · Não incomodar", "Focus · Do Not Disturb")}
                  right={<Toggle on={st.dnd} onChange={(v) => { if (N.setDnd(v)) setRT({ status: { ...st, dnd: v } }); else if (N.isNative) sys("policyAccess"); else toast(L("Disponível no APK", "Available in the APK")); }} />} />
              </Group>
              <Group C={C}>
                <Row C={C} icon={<I.Info size={18} />} color="gray" label={L("Geral", "General")} onClick={() => push("general")} />
                <Row C={C} icon={<I.Grid size={16} />} color="gray" label={L("Centro de controlo", "Control Center")} onClick={() => push("controlcenter")} />
                <Row C={C} icon={<I.Sun size={18} />} color="blue" label={L("Ecrã e brilho", "Display & Brightness")} onClick={() => push("display")} />
                <Row C={C} icon={<I.Grid size={16} />} color="indigo" label={L("Ecrã principal e Biblioteca", "Home Screen & App Library")} onClick={() => push("homescreen")} />
                <Row C={C} icon={<I.Sparkle size={16} />} color="purple" label={L("Dock e pastas", "Dock & Folders")} onClick={() => push("dock")} />
                <Row C={C} icon={<span className="w-4 h-2 rounded-full bg-white" />} color="black" label="Dynamic Island" onClick={() => push("island")} />
                <Row C={C} icon={<I.Lock size={16} />} color="blue" label={L("Ecrã de bloqueio", "Lock Screen")} onClick={() => push("lock")} />
                <Row C={C} icon={<I.Photo size={17} />} color="cyan" label={L("Papel de parede", "Wallpaper")} onClick={() => push("wallpaper")} />
                <Row C={C} icon={<I.Play size={15} />} color="teal" label={L("Animações", "Animations")} onClick={() => push("animations")} />
                <Row C={C} icon={<I.Contrast size={17} />} color="gray" label={L("Transparência", "Transparency")} onClick={() => push("transparency")} />
                <Row C={C} icon={<I.Hand size={18} />} color="blue" label={L("Acessibilidade", "Accessibility")} onClick={() => sys("accessibility")} external />
              </Group>
              <Group C={C}>
                <Row C={C} icon={<I.Shield size={16} />} color="blue" label={L("Permissões do Launcher", "Launcher Permissions")} onClick={() => push("permissions")} />
                <Row C={C} icon={<I.Battery size={22} level={st.battery} />} color="green" label={L("Bateria", "Battery")} value={`${st.battery}%`} onClick={() => sys("battery")} external />
                <Row C={C} icon={<I.Keyboard size={18} />} color="gray" label={L("Teclado", "Keyboard")} onClick={() => push("keyboard")} />
              </Group>
              <Group C={C}>
                <Row C={C} icon={<I.Info size={18} />} color="gray" label={L("Sobre e estado das funcionalidades", "About & feature status")} onClick={() => push("about")} />
              </Group>
            </>
          )}
        </>
      );
    }
    case "profile":
      return (
        <>
          <Group C={C} header={L("Nome", "Name")}>
            <div className="px-4 py-2.5"><input value={s.profileName} onChange={(e) => set({ profileName: e.target.value })} placeholder={L("O teu nome", "Your Name")} className="w-full bg-transparent outline-none text-[17px]" style={{ color: C.fg }} /></div>
          </Group>
          <Group C={C} header={L("Personalização", "Personalization")}>
            <Row C={C} label={L("Papel de parede", "Wallpaper")} onClick={() => push("wallpaper")} />
            <Row C={C} label={L("Ícones e ecrã principal", "Icons & Home Screen")} onClick={() => push("homescreen")} />
            <Row C={C} label={L("Modo claro e escuro", "Light & Dark")} onClick={() => push("display")} />
          </Group>
          <Group C={C} header={L("Privacidade", "Privacy")} footer={L("O Launcher não envia dados para a Internet. Preferências, disposição e ícones ficam guardados apenas neste dispositivo.", "The launcher sends no data to the internet. Preferences, layout and icons are stored only on this device.")}>
            <Row C={C} label={L("Dados de demonstração", "Demo data")} sub={L("Mostra exemplos claramente marcados «DEMO»", "Shows samples clearly marked “DEMO”")} right={<Toggle on={s.demo} onChange={(v) => set({ demo: v })} />} />
            <Row C={C} label={L("Feedback háptico", "Haptics")} right={<Toggle on={s.hapticsOn} onChange={(v) => set({ hapticsOn: v })} />} />
          </Group>
        </>
      );
    case "wallpaper":
      return <WallpaperPage C={C} dark={dark} />;
    case "homescreen":
      return (
        <>
          <Group C={C} header={L("Tamanho dos ícones", "Icon size")}>
            <Slider C={C} value={s.iconSize} min={0.8} max={1.2} onChange={(v) => set({ iconSize: v })} left={<span className="text-[12px]">A</span>} right={<span className="text-[18px]">A</span>} />
          </Group>
          <Group C={C} header={L("Grelha", "Grid")} footer={L("4 colunas reproduz o iPhone. A grelha adapta-se à altura do ecrã do Zenfone.", "4 columns matches the iPhone. The grid adapts to the Zenfone screen height.")}>
            <div className="px-4 pt-2 text-[15px]">{L("Colunas", "Columns")}</div>
            <Segmented dark={dark} value={s.columns} options={[[4, "4"], [5, "5"]]} onChange={(v) => { set({ columns: v }); loadApps(); }} />
            <div className="px-4 text-[15px]">{L("Filas", "Rows")}</div>
            <Segmented dark={dark} value={s.rows} options={[[5, "5"], [6, "6"], [7, "7"]]} onChange={(v) => { set({ rows: v }); loadApps(); }} />
          </Group>
          <Group C={C}>
            <Row C={C} label={L("Mostrar nomes das apps", "Show app names")} right={<Toggle on={s.showLabels} onChange={(v) => set({ showLabels: v })} />} />
            <Row C={C} label={L("Botão Pesquisar no ecrã", "Search button on Home")} right={<Toggle on={s.showSearchPill} onChange={(v) => set({ showSearchPill: v })} />} />
            <Row C={C} label={L("Ícones estilo iOS para apps do sistema", "iOS-style icons for system apps")} sub={L("Telefone, Mensagens, Câmara, Navegador… As restantes usam o ícone original.", "Phone, Messages, Camera, Browser… Others use the original icon.")} right={<Toggle on={s.iosIcons} onChange={(v) => set({ iosIcons: v })} />} />
            <Row C={C} label={L("Repor ícones personalizados", "Reset custom icons")} onClick={() => { set({ customIcons: {} }); toast(L("Ícones repostos", "Icons reset")); }} chevron={false} />
          </Group>
          <Group C={C} footer={L("Toque prolongado num ícone para editar, arrastar, criar pastas (larga uma app sobre outra) ou mudar de página (arrasta até à margem).", "Long-press an icon to edit, drag, create folders (drop an app onto another) or change pages (drag to the edge).")}>
            <Row C={C} label={L("Editar ecrã principal", "Edit Home Screen")} onClick={() => { setRT({ overlay: "none", editMode: true }); }} />
            <Row C={C} danger label={L("Repor disposição do ecrã principal", "Reset Home Screen Layout")} chevron={false} onClick={() => { useStore.getState().resetLayout(); loadApps(); toast(L("Disposição reposta", "Layout reset")); }} />
          </Group>
        </>
      );
    case "dock":
      return (
        <>
          <Group C={C} header="Dock" footer={L("Arrasta apps para dentro ou fora do dock no modo de edição.", "Drag apps in or out of the dock in edit mode.")}>
            <div className="px-4 pt-2 text-[15px]">{L("Número máximo de apps", "Maximum apps")}</div>
            <Segmented dark={dark} value={s.dockIcons} options={[[4, "4"], [5, "5"]]} onChange={(v) => set({ dockIcons: v })} />
          </Group>
          <Group C={C} header={L("Pastas", "Folders")} footer={L("Para criar uma pasta, arrasta uma app para cima de outra. Para renomear, abre a pasta no modo de edição.", "To create a folder, drag an app onto another. To rename, open the folder in edit mode.")}>
            <Row C={C} label={L("Desfocar fundo ao abrir pasta", "Blur background when opening folder")} right={<Toggle on={s.folderBlur} onChange={(v) => set({ folderBlur: v })} />} />
            <Row C={C} label={L("Pastas criadas", "Folders")} value={String(Object.keys(useStore.getState().folders).length)} />
          </Group>
        </>
      );
    case "animations":
      return (
        <>
          <Group C={C} header={L("Velocidade", "Speed")} footer={L("Valores menores tornam as animações mais rápidas.", "Lower values make animations faster.")}>
            <Slider C={C} value={s.animSpeed} min={0.5} max={1.5} onChange={(v) => set({ animSpeed: v })} left={<span className="text-[12px]">{L("Rápida", "Fast")}</span>} right={<span className="text-[12px]">{L("Lenta", "Slow")}</span>} />
          </Group>
          <Group C={C}>
            <Row C={C} label={L("Reduzir movimento", "Reduce Motion")} right={<Toggle on={s.reduceMotion} onChange={(v) => set({ reduceMotion: v })} />} />
          </Group>
        </>
      );
    case "transparency":
      return (
        <>
          <Group C={C} header={L("Opacidade do vidro (dock, pastas, pesquisa)", "Glass opacity (dock, folders, search)")}>
            <Slider C={C} value={s.transparency} min={0} max={1} onChange={(v) => set({ transparency: v })} />
          </Group>
          <Group C={C} header={L("Desfoque", "Blur")} footer={L("Desfoque menor reduz o consumo da GPU.", "Lower blur reduces GPU usage.")}>
            <Slider C={C} value={s.blur} min={0} max={50} step={1} onChange={(v) => set({ blur: v })} />
          </Group>
        </>
      );
    case "display":
      return (
        <>
          <Group C={C} header={L("Aspecto", "Appearance")}>
            <div className="flex justify-around py-4">
              {(["light", "dark"] as const).map((t) => (
                <button key={t} onClick={() => set({ theme: t })} className="flex flex-col items-center gap-2">
                  <div className="w-[78px] h-[160px] rounded-[14px] overflow-hidden relative border" style={{ borderColor: C.sep }}>
                    <img src={wallSrc(s.wallpaper, t === "dark")} className="w-full h-full object-cover" alt="" />
                    <div className="absolute inset-x-2 bottom-2 h-5 rounded-md" style={{ background: t === "dark" ? "rgba(40,40,45,.7)" : "rgba(255,255,255,.5)" }} />
                  </div>
                  <span className="text-[15px]">{t === "light" ? L("Claro", "Light") : L("Escuro", "Dark")}</span>
                  <span className="w-[22px] h-[22px] rounded-full border-2 flex items-center justify-center" style={{ borderColor: s.theme === t ? C.blue : C.sep, background: s.theme === t ? C.blue : "transparent" }}>{s.theme === t && <span className="text-white text-[12px]">✓</span>}</span>
                </button>
              ))}
            </div>
            <Row C={C} label={L("Automático (segue o Android)", "Automatic (follows Android)")} right={<Toggle on={s.theme === "auto"} onChange={(v) => set({ theme: v ? "auto" : dark ? "dark" : "light" })} />} />
          </Group>
          <Group C={C} header={L("Brilho", "Brightness")} footer={N.isNative && !st.writeSettings ? L("Para alterar o brilho do sistema concede «Modificar definições do sistema» em Permissões.", "To change system brightness grant “Modify system settings” in Permissions.") : nativeOnly}>
            <Slider C={C} value={st.brightness} min={0} max={1} onChange={(v) => { setRT({ status: { ...st, brightness: v } }); N.setBrightness(v); }} left={<I.Sun size={14} />} right={<I.Sun size={22} />} />
            <Row C={C} label={L("Definições de ecrã do Android", "Android display settings")} onClick={() => sys("display")} external />
          </Group>
        </>
      );
    case "language":
      return (
        <Group C={C} header={L("Idioma do Launcher", "Launcher language")} footer={L("O idioma do sistema Android altera-se nas definições do Android.", "The Android system language is changed in Android settings.")}>
          <Check C={C} label="Português" on={s.lang === "pt"} onClick={() => { set({ lang: "pt" }); loadApps(); }} />
          <Check C={C} label="English" on={s.lang === "en"} onClick={() => { set({ lang: "en" }); loadApps(); }} />
          <Row C={C} label={L("Idioma do sistema Android", "Android system language")} onClick={() => sys("language")} external />
        </Group>
      );
    case "notifications":
      return (
        <>
          <Group C={C} header={L("Acesso", "Access")} footer={L("O acesso às notificações permite mostrar as notificações reais, abri-las na app de origem e ler a sessão multimédia activa para a Dynamic Island. Nada sai do dispositivo.", "Notification access lets the launcher show real notifications, open them in the source app and read the active media session for the Dynamic Island. Nothing leaves the device.")}>
            <Row C={C} label={L("Acesso às notificações", "Notification access")} value={N.isNative ? (st.notifAccess ? L("Concedido", "Granted") : L("Em falta", "Missing")) : "—"} onClick={() => sys("notifAccess")} external />
          </Group>
          <Group C={C} header={L("Pré-visualizações", "Show Previews")}>
            <Check C={C} label={L("Sempre", "Always")} on={s.notifPreview === "always"} onClick={() => set({ notifPreview: "always" })} />
            <Check C={C} label={L("Quando desbloqueado", "When Unlocked")} on={s.notifPreview === "unlocked"} onClick={() => set({ notifPreview: "unlocked" })} />
            <Check C={C} label={L("Nunca", "Never")} on={s.notifPreview === "never"} onClick={() => set({ notifPreview: "never" })} />
          </Group>
          <Group C={C}>
            <Row C={C} label={L("Agrupar por app", "Group by app")} right={<Toggle on={s.notifGroup} onChange={(v) => set({ notifGroup: v })} />} />
            <Row C={C} label={L("Mostrar no ecrã de bloqueio", "Show on Lock Screen")} right={<Toggle on={s.notifOnLock} onChange={(v) => set({ notifOnLock: v })} />} />
            <Row C={C} label={L("Notificações por app (Android)", "Per-app notifications (Android)")} onClick={() => sys("notifications")} external />
          </Group>
        </>
      );
    case "island":
      return (
        <>
          <Group C={C} footer={L("O Zenfone 8 Flip não tem orifício para câmara frontal (a câmara é rotativa), por isso a ilha é desenhada pelo Launcher no centro do topo. Ajusta a posição e o tamanho.", "The Zenfone 8 Flip has no front camera hole (flip camera), so the island is drawn by the launcher at the top center. Adjust position and size.")}>
            <Row C={C} label={L("Mostrar Dynamic Island", "Show Dynamic Island")} right={<Toggle on={s.islandEnabled} onChange={(v) => set({ islandEnabled: v })} />} />
            <Row C={C} label={L("Indicador de carregamento", "Charging indicator")} right={<Toggle on={s.islandCharging} onChange={(v) => set({ islandCharging: v })} />} />
          </Group>
          <Group C={C} header={L("Posição vertical", "Vertical offset")}><Slider C={C} value={s.islandOffset} min={-8} max={30} step={1} onChange={(v) => set({ islandOffset: v })} /></Group>
          <Group C={C} header={L("Tamanho", "Size")}><Slider C={C} value={s.islandScale} min={0.8} max={1.25} onChange={(v) => set({ islandScale: v })} /></Group>
          <Group C={C} header={L("Fontes de dados", "Data sources")} footer={L("Música: sessões multimédia reais (requer acesso às notificações). Chamadas: estado real do telefone (requer permissão Telefone). Sem acesso, a ilha permanece em repouso — não são mostrados dados fictícios.", "Music: real media sessions (requires notification access). Calls: real phone state (requires Phone permission). Without access the island stays idle — no fake data is shown.")}>
            <Row C={C} label={L("Sessões multimédia", "Media sessions")} value={N.isNative ? (st.notifAccess ? "✓" : L("Em falta", "Missing")) : "—"} onClick={() => sys("notifAccess")} external />
            <Row C={C} label={L("Estado das chamadas", "Call state")} value={N.isNative ? (st.phonePerm ? "✓" : L("Em falta", "Missing")) : "—"} onClick={() => N.requestPermission("phone")} />
          </Group>
        </>
      );
    case "lock":
      return (
        <>
          <Group C={C} header={L("Mostrar ecrã complementar", "Show companion screen")} footer={L("Este ecrã NÃO substitui nem contorna o bloqueio seguro do Android (PIN, impressão digital). Em «Automático» só aparece ao ligar o ecrã quando o dispositivo não tem bloqueio seguro, para evitar bloqueio duplo.", "This screen does NOT replace or bypass Android's secure lock (PIN, fingerprint). In “Automatic” it only appears on screen-on when the device has no secure lock, to avoid a double lock.")}>
            <Check C={C} label={L("Automático", "Automatic")} on={s.lockEnabled === "auto"} onClick={() => set({ lockEnabled: "auto" })} />
            <Check C={C} label={L("Sempre ao ligar o ecrã", "Always on screen-on")} on={s.lockEnabled === "always"} onClick={() => set({ lockEnabled: "always" })} />
            <Check C={C} label={L("Nunca (apenas pelo botão ⏻ no Centro de Controlo)", "Never (only via ⏻ in Control Center)")} on={s.lockEnabled === "never"} onClick={() => set({ lockEnabled: "never" })} />
          </Group>
          <Group C={C} header={L("Relógio", "Clock")}>
            <Segmented dark={dark} value={s.lockClock} options={[["thin", L("Fino", "Thin")], ["bold", L("Arredondado", "Rounded")]]} onChange={(v) => set({ lockClock: v })} />
            <Row C={C} label={L("Legenda «ecrã complementar»", "“Companion screen” caption")} right={<Toggle on={s.lockCaption} onChange={(v) => set({ lockCaption: v })} />} />
          </Group>
          <Group C={C}><Row C={C} label={L("Pré-visualizar agora", "Preview now")} onClick={() => setRT({ overlay: "none", locked: true })} /></Group>
        </>
      );
    case "controlcenter": {
      const names: Record<string, string> = {
        darkmode: L("Modo escuro (Launcher)", "Dark Mode (launcher)"), calculator: L("Calculadora", "Calculator"), battery: L("Poupança de bateria", "Battery Saver"), cast: L("Transmitir ecrã", "Screen Mirroring"),
        timer: L("Temporizador", "Timer"), alarm: L("Alarme", "Alarm"), camera: L("Câmara", "Camera"), flashlight: L("Lanterna", "Flashlight"), hotspot: L("Ponto de acesso", "Hotspot"),
        location: L("Localização", "Location"), nfc: "NFC", dataUsage: L("Utilização de dados", "Data Usage"),
      };
      return (
        <>
          <Group C={C} header={L("Controlos incluídos", "Included controls")} footer={L("Toca para remover. Abre o Centro de Controlo deslizando para baixo a partir do canto superior direito.", "Tap to remove. Open Control Center by swiping down from the top-right corner.")}>
            {s.ccShortcuts.map((k) => <Row key={k} C={C} label={names[k]} right={<span className="w-6 h-6 rounded-full bg-[#FF3B30] text-white flex items-center justify-center"><I.Minus size={12} /></span>} onClick={() => set({ ccShortcuts: s.ccShortcuts.filter((x) => x !== k) })} />)}
          </Group>
          <Group C={C} header={L("Mais controlos", "More controls")}>
            {ALL_CC_SHORTCUTS.filter((k) => !s.ccShortcuts.includes(k)).map((k) => <Row key={k} C={C} label={names[k]} right={<span className="w-6 h-6 rounded-full bg-[#34C759] text-white flex items-center justify-center"><I.Plus size={12} /></span>} onClick={() => set({ ccShortcuts: [...s.ccShortcuts, k] })} />)}
          </Group>
        </>
      );
    }
    case "keyboard":
      return (
        <>
          <Group C={C} footer={L("O teclado iOS é um método de introdução Android independente. Activa-o nas definições do Android e escolhe-o quando estiveres a escrever.", "The iOS keyboard is a standalone Android input method. Enable it in Android settings and pick it while typing.")}>
            <Row C={C} label={L("Activar «Teclado iOS»", "Enable “iOS Keyboard”")} value={N.isNative ? (st.imeEnabled ? L("Activo", "Enabled") : L("Inactivo", "Disabled")) : undefined} onClick={() => sys("ime")} external />
            <Row C={C} label={L("Escolher teclado", "Choose keyboard")} onClick={() => sys("imePicker")} external />
          </Group>
          <Group C={C} header={L("Experimentar (pré-visualização)", "Try it (preview)")}>
            <div className="px-4 py-3 min-h-[60px] text-[17px] whitespace-pre-wrap">{kbText || <span style={{ color: C.sub }}>{L("Escreve aqui…", "Type here…")}</span>}<span className="ios-caret" /></div>
          </Group>
          <div className="-mx-4 mt-4"><IosKeyboard dark={dark} value={kbText} onChange={setKbText} /></div>
        </>
      );
    case "permissions":
      return (
        <>
          {!N.isNative && <p className="mt-4 text-[13px]" style={{ color: C.sub }}>{L("Estás a ver a pré-visualização no navegador. As permissões aplicam-se apenas no APK Android.", "You're viewing the browser preview. Permissions apply only in the Android APK.")}</p>}
          <Group C={C} footer={L("Todas as permissões são opcionais e concedidas pelos ecrãs oficiais do Android. O Launcher funciona sem root.", "All permissions are optional and granted via official Android screens. The launcher works without root.")}>
            <Row C={C} label={L("Launcher predefinido", "Default launcher")} value={st.defaultLauncher ? "✓" : L("Não", "No")} onClick={() => sys("home")} external />
            <Row C={C} label={L("Acesso às notificações", "Notification access")} sub={L("Notificações e música actual", "Notifications & now playing")} value={st.notifAccess ? "✓" : L("Não", "No")} onClick={() => sys("notifAccess")} external />
            <Row C={C} label={L("Acesso «Não incomodar»", "Do Not Disturb access")} sub={L("Foco e modo silencioso", "Focus & silent mode")} value={st.dndAccess ? "✓" : L("Não", "No")} onClick={() => sys("policyAccess")} external />
            <Row C={C} label={L("Modificar definições do sistema", "Modify system settings")} sub={L("Brilho e bloqueio de rotação", "Brightness & rotation lock")} value={st.writeSettings ? "✓" : L("Não", "No")} onClick={() => sys("writeSettings")} external />
            <Row C={C} label={L("Telefone", "Phone")} sub={L("Indicador de chamada na Dynamic Island", "Call indicator in the Dynamic Island")} value={st.phonePerm ? "✓" : L("Não", "No")} onClick={() => N.requestPermission("phone")} />
            <Row C={C} label={L("Informações da app", "App info")} onClick={() => sys("appSettings")} external />
          </Group>
        </>
      );
    case "general":
      return (
        <>
          <Group C={C}>
            <Row C={C} label={L("Sobre", "About")} onClick={() => push("about")} />
            <Row C={C} label={L("Idioma", "Language")} value={s.lang === "en" ? "English" : "Português"} onClick={() => push("language")} />
            <Row C={C} label={L("Teclado", "Keyboard")} onClick={() => push("keyboard")} />
            <Row C={C} label={L("Launcher predefinido", "Default launcher")} onClick={() => sys("home")} external />
            <Row C={C} label={L("Definições completas do Android", "Full Android settings")} onClick={() => sys("settings")} external />
          </Group>
          <Group C={C}>
            <Row C={C} danger chevron={false} label={L("Repor todos os ajustes do Launcher", "Reset all launcher settings")} onClick={() => { set(defaultSettings(N.isNative)); toast(L("Ajustes repostos", "Settings reset")); }} />
          </Group>
        </>
      );
    case "about":
      return <AboutPage C={C} />;
  }
  return null;
}

function WallpaperPage({ C, dark }: { C: Col; dark: boolean }) {
  const L = useL();
  const s = useStore((x) => x.settings);
  const set = useStore((x) => x.set);
  const file = useRef<HTMLInputElement>(null);
  const target = useRef<"home" | "lock">("home");
  const pick = (t: "home" | "lock") => { target.current = t; file.current?.click(); };
  const onFile = (f?: File) => {
    if (!f) return;
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, 1440 / Math.max(img.width, img.height));
      const c = document.createElement("canvas");
      c.width = img.width * scale; c.height = img.height * scale;
      c.getContext("2d")!.drawImage(img, 0, 0, c.width, c.height);
      const data = c.toDataURL("image/jpeg", 0.85);
      set(target.current === "home" ? { wallpaper: data } : { lockWallpaper: data });
      URL.revokeObjectURL(img.src);
    };
    img.src = URL.createObjectURL(f);
  };
  const Thumb = ({ src, label, onClick, active }: { src: string; label: string; onClick: () => void; active?: boolean }) => (
    <button onClick={onClick} className="flex flex-col items-center gap-1.5">
      <img src={src} alt="" className="w-[72px] h-[150px] object-cover rounded-[12px]" style={{ outline: active ? `3px solid ${C.blue}` : "none", outlineOffset: 2 }} />
      <span className="text-[12px]" style={{ color: C.sub }}>{label}</span>
    </button>
  );
  return (
    <>
      <input ref={file} type="file" accept="image/*" className="hidden" onChange={(e) => onFile(e.target.files?.[0])} />
      <Group C={C}>
        <div className="flex justify-center gap-6 py-5">
          <div className="flex flex-col items-center gap-2"><img src={wallSrc(s.lockWallpaper, dark)} className="w-[120px] h-[250px] object-cover rounded-[18px]" alt="" /><span className="text-[13px]" style={{ color: C.sub }}>{L("Bloqueio", "Lock Screen")}</span></div>
          <div className="flex flex-col items-center gap-2"><img src={wallSrc(s.wallpaper, dark)} className="w-[120px] h-[250px] object-cover rounded-[18px]" alt="" /><span className="text-[13px]" style={{ color: C.sub }}>{L("Ecrã principal", "Home Screen")}</span></div>
        </div>
      </Group>
      {(["home", "lock"] as const).map((t) => (
        <Group key={t} C={C} header={t === "home" ? L("Ecrã principal", "Home Screen") : L("Ecrã de bloqueio", "Lock Screen")}>
          <div className="flex gap-3 overflow-x-auto px-4 py-3 no-scrollbar" style={{ touchAction: "pan-x" }}>
            {WALLPAPERS.map((w) => <Thumb key={w.key} src={w.src} label={L(w.pt, w.en)} active={(t === "home" ? s.wallpaper : s.lockWallpaper) === w.key} onClick={() => set(t === "home" ? { wallpaper: w.key } : { lockWallpaper: w.key })} />)}
          </div>
          <Row C={C} label={L("Escolher da galeria…", "Choose from Photos…")} onClick={() => pick(t)} />
        </Group>
      ))}
      <Group C={C} footer={L("O fundo do ecrã principal em modo escuro usa automaticamente a variante «Noite» quando escolhes «Onda Rosa».", "In dark mode, “Pink Wave” automatically uses the “Night” variant.")}>
        <Row C={C} label={L("Papel de parede do sistema Android", "Android system wallpaper")} onClick={() => N.openPanel("wallpaper") || toast(L("Disponível no APK", "Available in the APK"))} external />
      </Group>
    </>
  );
}

function AboutPage({ C }: { C: Col }) {
  const L = useL();
  const real: [string, string][] = [
    [L("Launcher HOME predefinido, abrir apps reais com animação de zoom", "Default HOME launcher, open real apps with zoom animation"), "APK"],
    [L("Lista de apps instaladas, ícones originais, instalações/remoções em tempo real", "Installed apps, original icons, live install/uninstall"), "APK"],
    [L("Grelha 4 colunas, páginas, dock, pastas, arrastar, Biblioteca, pesquisa", "4-column grid, pages, dock, folders, drag, Library, search"), L("Real", "Real")],
    [L("Lanterna (CameraManager)", "Flashlight (CameraManager)"), "APK"],
    [L("Volume multimédia (AudioManager)", "Media volume (AudioManager)"), "APK"],
    [L("Brilho e bloqueio de rotação (com permissão)", "Brightness & rotation lock (with permission)"), "APK"],
    [L("Não incomodar e modo silencioso (com acesso)", "Do Not Disturb & silent (with access)"), "APK"],
    [L("Música actual + controlos (MediaSession)", "Now playing + controls (MediaSession)"), "APK"],
    [L("Notificações reais, agrupar, abrir, dispensar", "Real notifications, group, open, dismiss"), "APK"],
    [L("Estado de chamada na Dynamic Island", "Call state in the Dynamic Island"), "APK"],
    [L("Teclado iOS (método de introdução)", "iOS keyboard (input method)"), "APK"],
  ];
  const limited: [string, string][] = [
    [L("Wi-Fi, Bluetooth, dados, modo de voo", "Wi-Fi, Bluetooth, data, airplane"), L("Abre painel oficial", "Opens official panel")],
    [L("Ecrã de bloqueio", "Lock screen"), L("Complementar, não seguro", "Companion, not secure")],
    [L("Dynamic Island / Centro de Controlo", "Dynamic Island / Control Center"), L("Só dentro do Launcher", "Inside launcher only")],
    [L("Barra de estado Android", "Android status bar"), L("Ocultada no Launcher", "Hidden in launcher")],
  ];
  return (
    <>
      <Group C={C}>
        <Row C={C} label={L("Nome", "Name")} value="iPhone Experience" />
        <Row C={C} label={L("Versão", "Version")} value="1.0.0" />
        <Row C={C} label={L("Ambiente", "Environment")} value={N.isNative ? "Android (APK)" : L("Navegador (pré-visualização)", "Browser (preview)")} />
        <Row C={C} label={L("Alvo", "Target")} value="Zenfone 8 Flip · Android 13" />
      </Group>
      <Group C={C} header={L("Funcional", "Functional")}>
        {real.map(([a, b]) => <Row key={a} C={C} label={a} value={b} />)}
      </Group>
      <Group C={C} header={L("Limitado pelo Android (sem root)", "Limited by Android (no root)")} footer={L("Nenhum controlo simula uma alteração que não foi feita: quando o Android não permite alterar directamente, o Launcher abre o painel oficial.", "No control fakes a change: when Android doesn't allow a direct change, the launcher opens the official panel.")}>
        {limited.map(([a, b]) => <Row key={a} C={C} label={a} value={b} />)}
      </Group>
    </>
  );
}
