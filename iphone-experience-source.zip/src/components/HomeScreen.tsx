import { useEffect, useMemo, useRef, useState } from "react";
import { useStore, isFolder, useL, type Item, type Folder } from "@/lib/store";
import { useRT, openApp, placedIds, toast, SETTINGS_ID } from "@/lib/apps";
import * as N from "@/lib/native";
import { IconImage, FolderIcon } from "./AppIcon";
import { IosIcon, IOS_ICON_KEYS } from "./IosIcons";
import { Search, Edit, Info, Trash, Minus, Grid, Sparkle } from "./Glyphs";

type Src = { c: "page"; p: number } | { c: "dock" } | { c: "folder"; f: string } | { c: "lib" };
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

function parseSrc(s: string): Src {
  if (s.startsWith("page:")) return { c: "page", p: +s.slice(5) };
  if (s.startsWith("folder:")) return { c: "folder", f: s.slice(7) };
  if (s === "dock") return { c: "dock" };
  return { c: "lib" };
}

interface L { pages: Item[][]; dock: Item[]; folders: Record<string, Folder> }
const snap = (): L => {
  const s = useStore.getState();
  return { pages: s.pages.map((p) => [...p]), dock: [...s.dock], folders: Object.fromEntries(Object.entries(s.folders).map(([k, f]) => [k, { ...f, apps: [...f.apps] }])) };
};
const commit = (l: L) => useStore.getState().setLayout(l.pages, l.dock, l.folders);

function normalize(l: L, cap: number) {
  for (let i = 0; i < l.pages.length; i++) {
    while (l.pages[i].length > cap) {
      const extra = l.pages[i].pop()!;
      if (!l.pages[i + 1]) l.pages.push([]);
      l.pages[i + 1].unshift(extra);
    }
  }
}
function removeEverywhere(l: L, id: string) {
  l.pages = l.pages.map((p) => p.filter((x) => x !== id));
  l.dock = l.dock.filter((x) => x !== id);
}
function dissolveFolders(l: L) {
  for (const [k, f] of Object.entries(l.folders)) {
    const fid = "folder:" + k;
    if (f.apps.length <= 1) {
      const rep = f.apps[0];
      const swap = (arr: Item[]) => {
        const i = arr.indexOf(fid);
        if (i >= 0) rep ? arr.splice(i, 1, rep) : arr.splice(i, 1);
      };
      l.pages.forEach(swap);
      swap(l.dock);
      delete l.folders[k];
    }
  }
}

export default function HomeScreen({ W, H, top, dark }: { W: number; H: number; top: number; dark: boolean }) {
  const L = useL();
  const settings = useStore((s) => s.settings);
  const pages = useStore((s) => s.pages);
  const dock = useStore((s) => s.dock);
  const folders = useStore((s) => s.folders);
  const apps = useRT((s) => s.apps);
  const editMode = useRT((s) => s.editMode);
  const setRT = useRT((s) => s.set);

  const [page, setPage] = useState(0);
  const pageRef = useRef(0);
  pageRef.current = page;
  const [openFolder, setOpenFolder] = useState<string | null>(null);
  const [dragId, setDragId] = useState<string | null>(null);
  const [merge, setMerge] = useState<string | null>(null);
  const [menu, setMenu] = useState<{ id: string; src: string; rect: DOMRect } | null>(null);
  const [confirm, setConfirm] = useState<string | null>(null);
  const [picker, setPicker] = useState<string | null>(null);
  const [showDots, setShowDots] = useState(false);
  const [libQuery, setLibQuery] = useState("");
  const [extraPage, setExtraPage] = useState(false);

  const root = useRef<HTMLDivElement>(null);
  const strip = useRef<HTMLDivElement>(null);
  const ghost = useRef<HTMLDivElement>(null);
  const folderPanel = useRef<HTMLDivElement>(null);
  const g = useRef<any>({ mode: "idle" });

  // ---------- métricas ----------
  const cols = settings.columns;
  const icon = Math.round(clamp(W * (cols === 4 ? 0.153 : 0.13) * settings.iconSize, 40, 92));
  const padSide = Math.round(W * (cols === 4 ? 0.035 : 0.02));
  const cellW = (W - 2 * padSide) / cols;
  const gridTop = top + 16;
  const dockMargin = Math.round(W * 0.03);
  const dockH = icon + Math.round(icon * 0.5);
  const dockTop = H - Math.round(W * 0.03) - dockH - 6;
  const avail = dockTop - 46 - gridTop;
  const rowPitch = Math.min(avail / settings.rows, icon * 1.42 + (settings.showLabels ? 10 : 0));
  const cap = cols * settings.rows;
  const dockW = W - dockMargin * 2;
  const libIndex = pages.length + (extraPage ? 1 : 0);
  const pageCount = libIndex + 1;
  const dur = settings.reduceMotion ? 0 : 0.35 * settings.animSpeed;
  const glassA = 0.12 + settings.transparency * 0.25;

  const setStrip = (dx: number, animate: boolean, p = page) => {
    if (!strip.current) return;
    strip.current.style.transition = animate ? `transform ${0.4 * settings.animSpeed}s cubic-bezier(.2,.9,.25,1)` : "none";
    strip.current.style.transform = `translate3d(${-p * W + dx}px,0,0)`;
  };
  useEffect(() => setStrip(0, true), [page, W]); // eslint-disable-line
  useEffect(() => {
    if (page > pageCount - 1) setPage(pageCount - 1);
  }, [pageCount, page]);

  // Home premido novamente -> fecha pasta/edição e volta à página 1
  useEffect(() => N.onNative("home", () => {
    setOpenFolder(null); setMenu(null); setConfirm(null); setPicker(null);
    if (useRT.getState().editMode) exitEdit(); else setPage(0);
  }), []); // eslint-disable-line
  useEffect(() => N.onNative("back", () => {
    if (menu) setMenu(null); else if (openFolder) setOpenFolder(null); else if (useRT.getState().editMode) exitEdit();
  }), [menu, openFolder]); // eslint-disable-line

  function exitEdit() {
    const l = snap();
    l.pages = l.pages.filter((p, i) => p.length || i === 0);
    commit(l);
    setExtraPage(false);
    setRT({ editMode: false });
  }

  const posOf = (i: number) => ({ left: padSide + (i % cols) * cellW, top: gridTop + Math.floor(i / cols) * rowPitch });
  const dockPos = (i: number, n: number) => dockMargin + (dockW / Math.max(n, 1)) * (i + 0.5) - icon / 2;

  // ---------- hit test ----------
  function hit(x: number, y: number): any {
    if (openFolder && folderPanel.current) {
      const r = folderPanel.current.getBoundingClientRect();
      const rr = root.current!.getBoundingClientRect();
      const lx = x + rr.left, ly = y + rr.top;
      if (lx < r.left - 10 || lx > r.right + 10 || ly < r.top - 10 || ly > r.bottom + 10) return { c: "outside" };
      const fc = 3, fw = (r.width - 32) / fc;
      const col = clamp(Math.floor((lx - r.left - 16) / fw), 0, fc - 1);
      const row = Math.max(0, Math.floor((ly - r.top - 20) / (icon * 1.45)));
      return { c: "folder", index: row * fc + col };
    }
    if (y > dockTop - 8) {
      const n = useStore.getState().dock.length;
      const slot = dockW / Math.max(n, 1);
      const idx = clamp(Math.floor((x - dockMargin) / slot), 0, n);
      const cx = dockPos(Math.min(idx, n - 1), n) + icon / 2;
      const target = useStore.getState().dock[idx];
      return { c: "dock", index: idx, merge: target && Math.abs(x - cx) < icon * 0.33 ? target : undefined };
    }
    if (page >= pages.length) return null;
    const col = clamp(Math.floor((x - padSide) / cellW), 0, cols - 1);
    const row = clamp(Math.floor((y - gridTop) / rowPitch), 0, settings.rows - 1);
    const pg = useStore.getState().pages[page] || [];
    const idx = row * cols + col;
    const cx = padSide + col * cellW + cellW / 2, cy = gridTop + row * rowPitch + icon / 2;
    const target = pg[idx];
    const near = Math.hypot(x - cx, y - cy) < icon * 0.36;
    return { c: "page", p: page, index: Math.min(idx, pg.length), merge: near && target ? target : undefined };
  }

  function locate(id: string): Src | null {
    const s = useStore.getState();
    const pi = s.pages.findIndex((p) => p.includes(id));
    if (pi >= 0) return { c: "page", p: pi };
    if (s.dock.includes(id)) return { c: "dock" };
    for (const [k, f] of Object.entries(s.folders)) if (f.apps.includes(id)) return { c: "folder", f: k };
    return null;
  }

  function moveTo(id: string, dest: any) {
    const l = snap();
    const src = locate(id);
    if (!src) return;
    if (dest.c === "folder") {
      const f = l.folders[openFolder!];
      const cur = f.apps.indexOf(id);
      const to = clamp(dest.index, 0, f.apps.length - 1);
      if (cur === to || cur < 0) return;
      f.apps.splice(cur, 1); f.apps.splice(to, 0, id);
      commit(l); return;
    }
    if (dest.c === "dock") {
      const cur = l.dock.indexOf(id);
      if (cur < 0 && l.dock.length >= settings.dockIcons) return;
      if (cur === dest.index || (cur >= 0 && cur === dest.index - 1 && dest.index === l.dock.length)) return;
      removeEverywhere(l, id);
      l.dock.splice(clamp(dest.index, 0, l.dock.length), 0, id);
    } else if (dest.c === "page") {
      while (l.pages.length <= dest.p) l.pages.push([]);
      const cur = l.pages[dest.p].indexOf(id);
      const to = clamp(dest.index, 0, l.pages[dest.p].length - (cur >= 0 ? 1 : 0));
      if (cur === to) return;
      removeEverywhere(l, id);
      l.pages[dest.p].splice(to, 0, id);
      normalize(l, cap);
    }
    commit(l);
  }

  function doMerge(id: string, target: string) {
    if (isFolder(id) || id === target) return;
    const l = snap();
    if (isFolder(target)) {
      const f = l.folders[target.slice(7)];
      removeEverywhere(l, id);
      if (!f.apps.includes(id)) f.apps.push(id);
    } else {
      const k = Math.random().toString(36).slice(2, 8);
      const name = folderName(apps[id]?.iosKey, apps[target]?.iosKey);
      l.folders[k] = { name, apps: [target, id] };
      removeEverywhere(l, id);
      const rep = (arr: Item[]) => { const i = arr.indexOf(target); if (i >= 0) arr[i] = "folder:" + k; };
      l.pages.forEach(rep); rep(l.dock);
    }
    commit(l);
    N.haptic(15);
  }

  function folderName(a?: string, b?: string) {
    const social = ["messages", "phone", "facetime", "mail", "contacts"];
    const util = ["calculator", "clock", "files", "voice", "translate", "notes", "reminders", "settings", "flashlight", "weather"];
    const media = ["music", "tv", "podcasts", "photos", "camera"];
    const inG = (arr: string[]) => (a && arr.includes(a)) || (b && arr.includes(b));
    if (inG(social)) return L("Social", "Social");
    if (inG(media)) return L("Multimédia", "Entertainment");
    if (inG(util)) return L("Utilitários", "Utilities");
    return L("Pasta", "Folder");
  }

  function pullOutOfFolder(id: string) {
    const l = snap();
    const f = l.folders[openFolder!];
    f.apps = f.apps.filter((x) => x !== id);
    const p = Math.min(page, l.pages.length - 1);
    l.pages[p].push(id);
    normalize(l, cap);
    dissolveFolders(l);
    commit(l);
    setOpenFolder(null);
    g.current.src = { c: "page", p };
  }

  // ---------- gestos ----------
  const onDown = (e: React.PointerEvent) => {
    const t = e.target as HTMLElement;
    if (t.closest("[data-nocap]")) return;
    const rr = root.current!.getBoundingClientRect();
    const x = e.clientX - rr.left, y = e.clientY - rr.top;
    const el = t.closest("[data-item]") as HTMLElement | null;
    clearTimeout(g.current.lp);
    g.current = { mode: "pending", sx: x, sy: y, x, y, t0: Date.now(), id: el?.dataset.item, srcS: el?.dataset.src, src: el ? parseSrc(el.dataset.src!) : null, pid: e.pointerId, inLib: !!t.closest("[data-lib]") };
    try { root.current!.setPointerCapture(e.pointerId); } catch { /* */ }
    if (el) {
      if (useRT.getState().editMode && g.current.src.c !== "lib") {
        g.current.lp = setTimeout(() => g.current.mode === "pending" && startDrag(), 260);
      } else {
        g.current.lp = setTimeout(() => {
          if (g.current.mode !== "pending") return;
          g.current.mode = "menu";
          const iconEl = el.querySelector("[data-icon]") as HTMLElement;
          setMenu({ id: el.dataset.item!, src: el.dataset.src!, rect: (iconEl || el).getBoundingClientRect() });
          if (settings.hapticsOn) N.haptic(18);
        }, 480);
      }
    }
  };

  function startDrag() {
    const s = g.current;
    if (!s.id || s.src?.c === "lib") return;
    s.mode = "drag";
    setMenu(null);
    if (!useRT.getState().editMode) setRT({ editMode: true });
    setExtraPage(true);
    setDragId(s.id);
    if (settings.hapticsOn) N.haptic(10);
    requestAnimationFrame(() => positionGhost(s.x, s.y));
  }
  function positionGhost(x: number, y: number) {
    if (ghost.current) ghost.current.style.transform = `translate3d(${x - icon / 2}px, ${y - icon / 2}px, 0) scale(1.12)`;
  }

  const onMove = (e: React.PointerEvent) => {
    const s = g.current;
    if (s.mode === "idle" || e.pointerId !== s.pid) return;
    const rr = root.current!.getBoundingClientRect();
    const x = e.clientX - rr.left, y = e.clientY - rr.top;
    s.x = x; s.y = y;
    const dx = x - s.sx, dy = y - s.sy;
    if (s.mode === "pending" || s.mode === "menu") {
      if (Math.hypot(dx, dy) < 9) return;
      clearTimeout(s.lp);
      if (s.mode === "menu" || (useRT.getState().editMode && s.id && s.src?.c !== "lib")) return startDrag();
      if (s.sy < top + 6 && dy > 0 && Math.abs(dy) > Math.abs(dx)) {
        s.mode = "done";
        setRT({ overlay: s.sx > W * 0.55 ? "cc" : "nc" });
        return;
      }
      if (Math.abs(dx) > Math.abs(dy)) { s.mode = "swipe"; setShowDots(true); }
      else if (dy > 0 && !s.inLib && !openFolder && !useRT.getState().editMode) { s.mode = "done"; setRT({ overlay: "spotlight" }); return; }
      else { s.mode = "done"; return; }
    }
    if (s.mode === "swipe") {
      if (openFolder) return;
      let ddx = dx;
      if ((page === 0 && dx > 0) || (page === pageCount - 1 && dx < 0)) ddx = dx * 0.3;
      setStrip(ddx, false);
    } else if (s.mode === "drag") {
      positionGhost(x, y);
      handleDragHover(x, y);
    }
  };

  function handleDragHover(x: number, y: number) {
    const s = g.current;
    // mudança de página nas extremidades
    if (!openFolder && (x < 14 || x > W - 14) && y < dockTop - 10) {
      if (!s.edgeT) s.edgeT = setTimeout(() => {
        s.edgeT = null;
        const np = clamp(pageRef.current + (x < 14 ? -1 : 1), 0, useStore.getState().pages.length);
        if (np === pageRef.current) return;
        if (np >= useStore.getState().pages.length) {
          const l = snap(); l.pages.push([]); commit(l);
        }
        moveTo(s.id, { c: "page", p: np, index: 999 });
        setPage(np);
      }, 650);
      return;
    } else if (s.edgeT) { clearTimeout(s.edgeT); s.edgeT = null; }

    const h = hit(x, y);
    if (!h) return;
    if (h.c === "outside") {
      if (!s.outT) s.outT = setTimeout(() => { s.outT = null; if (g.current.mode === "drag") pullOutOfFolder(s.id); }, 280);
      return;
    } else if (s.outT) { clearTimeout(s.outT); s.outT = null; }

    if (h.merge && h.merge !== s.id && !isFolder(s.id)) {
      const key = "m:" + h.merge;
      if (s.hoverKey !== key) {
        s.hoverKey = key; clearTimeout(s.hoverT);
        s.hoverT = setTimeout(() => { setMerge(h.merge); if (settings.hapticsOn) N.haptic(8); }, 380);
      }
      return;
    }
    const key = `${h.c}:${h.p ?? ""}:${h.index}`;
    if (s.hoverKey !== key) {
      s.hoverKey = key; clearTimeout(s.hoverT); setMerge(null);
      s.hoverT = setTimeout(() => moveTo(s.id, h), 110);
    }
  }

  const onUp = (e: React.PointerEvent) => {
    const s = g.current;
    if (e.pointerId !== s.pid) return;
    clearTimeout(s.lp); clearTimeout(s.hoverT); clearTimeout(s.edgeT); clearTimeout(s.outT);
    const dx = s.x - s.sx;
    if (s.mode === "swipe") {
      const v = dx / Math.max(1, Date.now() - s.t0);
      let np = page;
      if (dx < -W * 0.2 || v < -0.45) np = Math.min(page + 1, pageCount - 1);
      else if (dx > W * 0.2 || v > 0.45) np = Math.max(page - 1, 0);
      if (np === page) setStrip(0, true); else setPage(np);
      setTimeout(() => setShowDots(false), 1200);
    } else if (s.mode === "drag") {
      if (merge) doMerge(s.id, merge);
      else {
        const l = snap(); dissolveFolders(l); commit(l);
      }
      setMerge(null); setDragId(null);
    } else if (s.mode === "pending" && e.type === "pointerup") {
      tap(s);
    }
    g.current = { mode: "idle" };
  };

  function tap(s: any) {
    const edit = useRT.getState().editMode;
    if (!s.id) {
      if (edit) exitEdit();
      else if (openFolder) setOpenFolder(null);
      return;
    }
    if (isFolder(s.id)) { setOpenFolder(s.id.slice(7)); return; }
    if (edit) return;
    const el = root.current!.querySelector(`[data-item="${CSS.escape(s.id)}"][data-src="${s.srcS}"] [data-icon]`) as HTMLElement | null;
    const rect = el?.getBoundingClientRect();
    if (el) { el.classList.add("ios-launch"); setTimeout(() => el.classList.remove("ios-launch"), 450); }
    openApp(s.id, rect);
  }

  // ---------- acções ----------
  function removeFromHome(id: string) {
    const l = snap();
    if (isFolder(id)) {
      const f = l.folders[id.slice(7)];
      const p = locate(id);
      removeEverywhere(l, id);
      const target = p?.c === "page" ? p.p : 0;
      l.pages[target].push(...(f?.apps || []));
      delete l.folders[id.slice(7)];
      normalize(l, cap);
    } else {
      removeEverywhere(l, id);
      for (const f of Object.values(l.folders)) f.apps = f.apps.filter((x) => x !== id);
      dissolveFolders(l);
    }
    commit(l);
  }
  function addToHome(id: string) {
    const l = snap();
    const last = l.pages[l.pages.length - 1];
    if (last.length >= cap) l.pages.push([id]); else last.push(id);
    commit(l);
    toast(L("Adicionada ao ecrã principal", "Added to Home Screen"));
  }

  // ---------- render helpers ----------
  const labelStyle: React.CSSProperties = { color: "#fff", fontSize: Math.max(10.5, icon * 0.18), textShadow: "0 1px 2px rgba(0,0,0,.35)", letterSpacing: "-0.01em" };

  const renderTile = (it: Item, src: string, opts: { label?: boolean; size?: number; light?: boolean } = {}) => {
    const size = opts.size ?? icon;
    const folder = isFolder(it) ? folders[it.slice(7)] : null;
    const app = folder ? null : apps[it];
    if (!folder && !app) return null;
    const name = folder ? folder.name : app!.label;
    const hidden = dragId === it;
    const jig = editMode && !hidden;
    return (
      <div data-item={it} data-src={src} className="flex flex-col items-center select-none" style={{ width: "100%", opacity: hidden ? 0 : 1 }}>
        <div className={"relative " + (jig ? "ios-jiggle" : "")} style={{ animationDelay: `${(it.length % 5) * -0.07}s` }}>
          <div data-icon className="transition-transform duration-200" style={{ transform: merge === it ? "scale(1.18)" : undefined }}>
            {folder ? <FolderIcon folder={folder} size={size} dark={dark} /> : <IconImage app={app!} size={size} />}
          </div>
          {merge === it && !folder && <div className="absolute -inset-2 ios-squircle" style={{ background: "rgba(255,255,255,.35)", zIndex: -1 }} />}
          {editMode && src !== "lib" && !hidden && (
            <button data-nocap onClick={() => setConfirm(it)} className="absolute -top-1.5 -left-1.5 w-[22px] h-[22px] rounded-full flex items-center justify-center"
              style={{ background: "rgba(120,120,128,.75)", backdropFilter: "blur(10px)", color: "#fff" }}>
              <Minus size={12} />
            </button>
          )}
        </div>
        {opts.label !== false && settings.showLabels && (
          <span className="mt-[5px] truncate text-center font-medium" style={{ ...labelStyle, maxWidth: cellW - 4, ...(opts.light ? { color: dark ? "#fff" : "#1c1c1e", textShadow: "none" } : {}) }}>{name}</span>
        )}
      </div>
    );
  };

  const allApps = useMemo(() => Object.values(apps).sort((a, b) => a.label.localeCompare(b.label)), [apps]);
  const libApps = allApps.filter((a) => a.label.toLowerCase().includes(libQuery.toLowerCase()));
  const placed = useMemo(() => placedIds(), [pages, dock, folders]); // eslint-disable-line

  const folder = openFolder ? folders[openFolder] : null;
  const pillVisible = settings.showSearchPill && !showDots && !editMode;

  return (
    <div ref={root} className="absolute inset-0 overflow-hidden" style={{ touchAction: "none" }}
      onPointerDown={onDown} onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onUp}>
      {/* páginas */}
      <div ref={strip} className="absolute top-0 left-0 h-full flex" style={{ width: W * pageCount }}>
        {[...pages, ...(extraPage ? [[]] : [])].map((p, pi) => (
          <div key={pi} className="relative h-full" style={{ width: W }}>
            {p.map((it, i) => {
              const pos = posOf(i);
              return (
                <div key={it} className="absolute" style={{ left: pos.left, top: pos.top, width: cellW, transition: dragId ? `left ${dur}s ease, top ${dur}s ease` : "none" }}>
                  {renderTile(it, `page:${pi}`)}
                </div>
              );
            })}
          </div>
        ))}
        {/* Biblioteca de Apps */}
        <div data-lib className="relative h-full" style={{ width: W }}>
          <div className="absolute inset-x-0 overflow-y-auto no-scrollbar" style={{ top: top + 6, bottom: 0, touchAction: "pan-y", padding: `0 ${padSide + 8}px 120px` }}>
            <div data-nocap className="flex items-center gap-2 h-10 rounded-xl px-3 mb-4" style={{ background: dark ? "rgba(60,60,67,.55)" : "rgba(255,255,255,.35)", backdropFilter: "blur(24px)" }}>
              <Search size={16} className="text-white/80" />
              <input value={libQuery} onChange={(e) => setLibQuery(e.target.value)} placeholder={L("Biblioteca de Apps", "App Library")} className="bg-transparent outline-none text-white placeholder-white/80 text-[16px] flex-1" />
            </div>
            <div className="grid grid-cols-4 gap-y-4">
              {libApps.map((a) => (
                <div key={a.id}>{renderTile(a.id, "lib", { size: Math.round(icon * 0.9) })}</div>
              ))}
            </div>
            <p className="text-center text-white/70 text-xs mt-6">{L(`${allApps.length} apps · ${allApps.length - placed.size} só na biblioteca`, `${allApps.length} apps · ${allApps.length - placed.size} library only`)}</p>
          </div>
        </div>
      </div>

      {/* Pesquisa / pontos de página */}
      <div className="absolute left-0 right-0 flex justify-center" style={{ top: dockTop - 38 }}>
        {pillVisible && page < libIndex ? (
          <button data-nocap onClick={() => setRT({ overlay: "spotlight" })} className="h-[28px] px-3 rounded-full flex items-center gap-1.5 text-white text-[13px] font-semibold ios-fade-in"
            style={{ background: `rgba(255,255,255,${glassA * 0.9})`, backdropFilter: `blur(${settings.blur}px) saturate(180%)`, WebkitBackdropFilter: `blur(${settings.blur}px) saturate(180%)` }}>
            <Search size={12} /> {L("Pesquisar", "Search")}
          </button>
        ) : (
          <div className="h-[28px] px-2.5 rounded-full flex items-center gap-[9px]" style={{ background: showDots || editMode ? `rgba(255,255,255,${glassA * 0.7})` : "transparent", backdropFilter: "blur(20px)" }}>
            {Array.from({ length: pageCount }).map((_, i) => (
              i === libIndex ? <Grid key={i} size={9} className={i === page ? "text-white" : "text-white/45"} /> :
              <span key={i} className="rounded-full" style={{ width: 7, height: 7, background: i === page ? "#fff" : "rgba(255,255,255,.45)" }} />
            ))}
          </div>
        )}
      </div>

      {/* Dock */}
      <div className="absolute" style={{ left: dockMargin, width: dockW, top: dockTop, height: dockH, borderRadius: dockH * 0.36,
        background: dark ? `rgba(40,40,45,${glassA + 0.1})` : `rgba(255,255,255,${glassA})`,
        backdropFilter: `blur(${settings.blur}px) saturate(180%)`, WebkitBackdropFilter: `blur(${settings.blur}px) saturate(180%)`,
        boxShadow: "inset 0 0.5px 0 rgba(255,255,255,.25)" }}>
        {dock.map((it, i) => (
          <div key={it} className="absolute" style={{ left: dockPos(i, dock.length) - dockMargin - (cellW - icon) / 2, width: cellW, top: (dockH - icon) / 2, transition: dragId ? `left ${dur}s ease` : "none" }}>
            {renderTile(it, "dock", { label: false })}
          </div>
        ))}
      </div>

      {/* Botão Concluído (modo de edição) */}
      {editMode && (
        <div data-nocap className="absolute flex justify-between items-center ios-fade-in" style={{ top: top - 4, left: 16, right: 16 }}>
          <button onClick={() => { exitEdit(); setRT({ overlay: "settings", settingsPage: "wallpaper" }); }} className="h-8 px-3.5 rounded-full text-[14px] font-semibold text-white" style={{ background: "rgba(255,255,255,.25)", backdropFilter: "blur(20px)" }}>{L("Editar", "Edit")}</button>
          <button onClick={exitEdit} className="h-8 px-3.5 rounded-full text-[14px] font-semibold text-white" style={{ background: "rgba(255,255,255,.25)", backdropFilter: "blur(20px)" }}>{L("OK", "Done")}</button>
        </div>
      )}

      {/* Pasta aberta */}
      {folder && (
        <div className="absolute inset-0 ios-fade-in" style={{ background: "rgba(0,0,0,.12)", backdropFilter: settings.folderBlur ? "blur(28px) saturate(140%)" : undefined, WebkitBackdropFilter: settings.folderBlur ? "blur(28px) saturate(140%)" : undefined, zIndex: 20 }}>
          <div className="absolute inset-x-0 flex flex-col items-center" style={{ top: H * 0.2 }}>
            {editMode ? (
              <input data-nocap value={folder.name} onChange={(e) => { const l = snap(); l.folders[openFolder!].name = e.target.value; commit(l); }}
                className="mb-5 text-center text-[26px] font-bold text-white bg-white/20 rounded-xl px-3 py-1 outline-none" style={{ width: W * 0.72 }} />
            ) : (
              <h2 className="mb-5 text-[28px] font-bold text-white" style={{ textShadow: "0 1px 6px rgba(0,0,0,.2)" }}>{folder.name}</h2>
            )}
            <div ref={folderPanel} className="relative ios-pop" style={{ width: W * 0.8, minHeight: W * 0.8, borderRadius: 38, padding: "20px 16px",
              background: dark ? "rgba(50,50,55,.5)" : "rgba(255,255,255,.3)", backdropFilter: "blur(30px) saturate(180%)", WebkitBackdropFilter: "blur(30px) saturate(180%)" }}>
              <div className="relative">
                {folder.apps.map((id, i) => (
                  <div key={id} className="absolute" style={{ left: (i % 3) * ((W * 0.8 - 32) / 3), top: Math.floor(i / 3) * icon * 1.45, width: (W * 0.8 - 32) / 3, transition: dragId ? `left ${dur}s, top ${dur}s` : "none" }}>
                    {renderTile(id, `folder:${openFolder}`)}
                  </div>
                ))}
                <div style={{ height: Math.ceil(folder.apps.length / 3) * icon * 1.45 }} />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Fantasma de arrastamento */}
      {dragId && (
        <div ref={ghost} className="absolute top-0 left-0 pointer-events-none" style={{ zIndex: 50, filter: "drop-shadow(0 10px 18px rgba(0,0,0,.35))" }}>
          {isFolder(dragId) ? folders[dragId.slice(7)] && <FolderIcon folder={folders[dragId.slice(7)]} size={icon} dark={dark} /> : apps[dragId] && <IconImage app={apps[dragId]} size={icon} />}
        </div>
      )}

      {/* Menu de contexto (toque prolongado) */}
      {menu && (
        <ContextMenu menu={menu} root={root.current!} icon={icon} dark={dark} onClose={() => setMenu(null)}
          items={[
            ...(isFolder(menu.id) ? [
              { label: L("Mudar nome", "Rename"), icon: <Edit size={18} />, run: () => { setOpenFolder(menu.id.slice(7)); setRT({ editMode: true }); } },
            ] : apps[menu.id] ? [
              ...(menu.src === "lib" && !placed.has(menu.id) ? [{ label: L("Adicionar ao ecrã principal", "Add to Home Screen"), icon: <Grid size={18} />, run: () => addToHome(menu.id) }] : []),
              ...(!apps[menu.id].internal ? [{ label: L("Alterar ícone", "Change icon"), icon: <Sparkle size={18} />, run: () => setPicker(menu.id) }] : []),
              ...(N.isNative && !apps[menu.id].internal ? [{ label: L("Informações da app", "App info"), icon: <Info size={18} />, run: () => N.appDetails(apps[menu.id].pkg) }] : []),
            ] : []),
            ...(menu.src !== "lib" ? [{ label: L("Editar ecrã principal", "Edit Home Screen"), icon: <Grid size={18} />, run: () => setRT({ editMode: true }) }] : []),
            ...(menu.src !== "lib" ? [{ label: isFolder(menu.id) ? L("Remover pasta", "Remove folder") : L("Remover app", "Remove App"), icon: <Minus size={18} />, danger: true, run: () => setConfirm(menu.id) }] : []),
          ]} />
      )}

      {/* Confirmação de remoção */}
      {confirm && (
        <Sheet dark={dark} onClose={() => setConfirm(null)}
          title={isFolder(confirm) ? L(`Remover a pasta «${folders[confirm.slice(7)]?.name}»?`, `Remove "${folders[confirm.slice(7)]?.name}" folder?`) : L(`Remover «${apps[confirm]?.label}»?`, `Remove "${apps[confirm]?.label}"?`)}
          subtitle={isFolder(confirm) ? L("As apps voltam ao ecrã principal.", "Apps return to the Home Screen.") : L("Remover do ecrã principal mantém a app na Biblioteca de Apps.", "Removing from Home Screen keeps the app in the App Library.")}
          actions={[
            ...(!isFolder(confirm) && N.isNative && apps[confirm] && !apps[confirm].internal ? [{ label: L("Desinstalar app", "Delete App"), danger: true, run: () => N.uninstall(apps[confirm].pkg) }] : []),
            ...(confirm !== SETTINGS_ID || true ? [{ label: isFolder(confirm) ? L("Remover pasta", "Remove Folder") : L("Remover do ecrã principal", "Remove from Home Screen"), run: () => removeFromHome(confirm) }] : []),
          ]} cancel={L("Cancelar", "Cancel")} />
      )}

      {/* Escolha de ícone */}
      {picker && apps[picker] && (
        <div data-nocap className="absolute inset-0 z-[60] flex items-end ios-fade-in" style={{ background: "rgba(0,0,0,.35)" }} onClick={() => setPicker(null)}>
          <div onClick={(e) => e.stopPropagation()} className="w-full rounded-t-[22px] p-5 ios-sheet-up" style={{ background: dark ? "#1c1c1e" : "#f2f2f7", color: dark ? "#fff" : "#000", paddingBottom: 34 }}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-[17px] font-semibold">{L("Ícone de", "Icon for")} {apps[picker].label}</h3>
              <button className="text-[#0A84FF] text-[17px]" onClick={() => setPicker(null)}>{L("OK", "Done")}</button>
            </div>
            <div className="grid grid-cols-6 gap-3 max-h-[40vh] overflow-y-auto" style={{ touchAction: "pan-y" }}>
              <button onClick={() => { useStore.getState().set({ customIcons: { ...settings.customIcons, [picker]: "original" } }); setPicker(null); }} className="flex flex-col items-center gap-1">
                <div className="w-11 h-11 ios-squircle bg-gray-400/40 flex items-center justify-center text-[10px] font-semibold">{L("Orig.", "Orig.")}</div>
              </button>
              {IOS_ICON_KEYS.map((k) => (
                <button key={k} onClick={() => { useStore.getState().set({ customIcons: { ...settings.customIcons, [picker]: k } }); setPicker(null); }}>
                  <div className="w-11 h-11 ios-squircle overflow-hidden"><IosIcon name={k} /></div>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ContextMenu({ menu, root, icon, dark, items, onClose }: { menu: { id: string; rect: DOMRect }; root: HTMLElement; icon: number; dark: boolean; items: { label: string; icon: React.ReactNode; danger?: boolean; run: () => void }[]; onClose: () => void }) {
  const apps = useRT((s) => s.apps);
  const folders = useStore((s) => s.folders);
  const rr = root.getBoundingClientRect();
  const x = menu.rect.left - rr.left, y = menu.rect.top - rr.top;
  const below = y < rr.height * 0.55;
  const menuW = 250;
  const left = clamp(x + icon / 2 - menuW / 2, 12, rr.width - menuW - 12);
  const f = isFolder(menu.id) ? folders[menu.id.slice(7)] : null;
  return (
    <div data-nocap className="absolute inset-0 z-[55] ios-fade-in" onPointerDown={(e) => { if (e.target === e.currentTarget) onClose(); }}
      style={{ background: "rgba(0,0,0,.18)", backdropFilter: "blur(18px)", WebkitBackdropFilter: "blur(18px)" }}>
      <div className="absolute pointer-events-none" style={{ left: x, top: y, transform: "scale(1.06)" }}>
        {f ? <FolderIcon folder={f} size={icon} dark={dark} /> : apps[menu.id] && <IconImage app={apps[menu.id]} size={icon} />}
      </div>
      <div className="absolute overflow-hidden ios-pop" style={{ left, width: menuW, ...(below ? { top: y + icon + 14 } : { bottom: rr.height - y + 14 }), borderRadius: 14,
        background: dark ? "rgba(37,37,40,.82)" : "rgba(250,250,252,.82)", backdropFilter: "blur(40px) saturate(180%)", WebkitBackdropFilter: "blur(40px) saturate(180%)", transformOrigin: below ? "top center" : "bottom center" }}>
        {items.map((it, i) => (
          <button key={i} onClick={() => { onClose(); it.run(); }} className="w-full h-[46px] px-4 flex items-center justify-between text-[17px] active:bg-black/10"
            style={{ color: it.danger ? "#FF3B30" : dark ? "#fff" : "#000", borderTop: i ? `0.5px solid ${dark ? "rgba(255,255,255,.12)" : "rgba(60,60,67,.22)"}` : undefined }}>
            <span>{it.label}</span>{it.icon}
          </button>
        ))}
      </div>
    </div>
  );
}

export function Sheet({ title, subtitle, actions, cancel, onClose, dark }: { title: string; subtitle?: string; actions: { label: string; danger?: boolean; run: () => void }[]; cancel: string; onClose: () => void; dark: boolean }) {
  const bg = dark ? "rgba(44,44,46,.92)" : "rgba(250,250,252,.92)";
  const sep = dark ? "rgba(255,255,255,.12)" : "rgba(60,60,67,.25)";
  return (
    <div data-nocap className="absolute inset-0 z-[60] flex flex-col justify-end p-2.5 pb-7 ios-fade-in" style={{ background: "rgba(0,0,0,.35)" }} onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className="ios-sheet-up">
        <div className="rounded-[14px] overflow-hidden mb-2" style={{ background: bg, backdropFilter: "blur(30px)" }}>
          <div className="px-4 py-3.5 text-center" style={{ borderBottom: `0.5px solid ${sep}` }}>
            <div className="text-[13px] font-semibold" style={{ color: dark ? "#ebebf599" : "#3c3c4399" }}>{title}</div>
            {subtitle && <div className="text-[13px] mt-0.5" style={{ color: dark ? "#ebebf599" : "#3c3c4399" }}>{subtitle}</div>}
          </div>
          {actions.map((a, i) => (
            <button key={i} onClick={() => { onClose(); a.run(); }} className="w-full h-[57px] text-[20px] active:bg-black/10" style={{ color: a.danger ? "#FF3B30" : "#0A84FF", borderTop: i ? `0.5px solid ${sep}` : undefined }}>{a.label}</button>
          ))}
        </div>
        <button onClick={onClose} className="w-full h-[57px] rounded-[14px] text-[20px] font-semibold text-[#0A84FF]" style={{ background: dark ? "#2c2c2e" : "#fff" }}>{cancel}</button>
      </div>
    </div>
  );
}

export { Trash };
