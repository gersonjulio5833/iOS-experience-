import { useRef, useState } from "react";

export const PT_WORDS = "a o e de que não da do em um uma para com os as por mais se como mas foi ao ele ela das dos tem à seu sua ou ser quando muito nos já está eu também só pelo pela até isso entre era depois sem mesmo aos ter seus quem nas me esse eles estão você vocês tinha foram essa num nem suas meu minha têm numa pelos elas havia seja qual será nós tenho lhe deles essas esses pelas este fosse dele tu te vos lhes meus minhas teu tua teus tuas nosso nossa nossos nossas dela delas esta estes estas aquele aquela aqueles aquelas isto aquilo estou está estamos estive esteve estivemos estiveram estava estávamos estavam obrigado obrigada olá bom boa dia noite tarde amanhã hoje ontem agora sempre nunca casa trabalho amor amigo amiga família telefone mensagem obrigadíssimo sim talvez porque quê onde quanto quantos pessoa pessoas tempo vida coisa coisas ano anos semana mês hora horas minuto minutos favor desculpa beijo beijos abraço saudade fazer feito vou vai vamos vem venho ir ver vejo vi falar falamos ligar ligo depois antes então ainda aqui ali lá cá bem mal melhor pior grande pequeno novo nova primeiro última último possível certo certeza claro ótimo fixe tudo nada algo alguém ninguém cada outro outra outros outras Portugal Lisboa Porto Brasil português".split(" ");

const ACCENTS: Record<string, string[]> = {
  a: ["á", "à", "â", "ã", "ä"], e: ["é", "ê", "è", "ë"], i: ["í", "ì", "î", "ï"], o: ["ó", "ô", "õ", "ò", "ö"], u: ["ú", "ü", "ù", "û"], c: ["ç"], n: ["ñ"],
};

export function suggest(word: string): string[] {
  if (!word) return ["Olá", "Obrigado", "Sim"];
  const w = word.toLowerCase();
  const norm = (s: string) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  const out = PT_WORDS.filter((x) => norm(x.toLowerCase()).startsWith(norm(w)) && x.toLowerCase() !== w).sort((a, b) => a.length - b.length).slice(0, 2);
  const cap = (s: string) => (word[0] === word[0].toUpperCase() ? s.charAt(0).toUpperCase() + s.slice(1) : s);
  return [`«${word}»`, ...out.map(cap)].slice(0, 3);
}

type Layer = "abc" | "123" | "#+=";

export default function IosKeyboard({ dark, value, onChange }: { dark: boolean; value: string; onChange: (v: string) => void }) {
  const [layer, setLayer] = useState<Layer>("abc");
  const [shift, setShift] = useState<0 | 1 | 2>(1);
  const [pop, setPop] = useState<{ key: string; x: number; y: number; variants?: string[]; sel?: number } | null>(null);
  const lastShift = useRef(0);
  const lp = useRef<any>(null);

  const bg = dark ? "#2c2c2e" : "#d1d3d9";
  const keyBg = dark ? "#6b6b6e" : "#fff";
  const spBg = dark ? "#464648" : "#abb0ba";
  const fg = dark ? "#fff" : "#000";

  const word = value.split(/\s/).pop() || "";
  const sug = suggest(word.replace(/[^\p{L}]/gu, ""));

  const type = (ch: string) => {
    const c = layer === "abc" && shift ? ch.toUpperCase() : ch;
    let v = value + c;
    if (ch === " " && value.endsWith(" ") && !value.endsWith(". ")) v = value.slice(0, -1) + ". ";
    onChange(v);
    if (shift === 1) setShift(0);
    if (ch === " " && /[.!?]\s$/.test(v)) setShift(1);
  };
  const del = () => onChange(value.slice(0, -1));

  const rows: Record<Layer, string[][]> = {
    abc: [["q", "w", "e", "r", "t", "y", "u", "i", "o", "p"], ["a", "s", "d", "f", "g", "h", "j", "k", "l"], ["z", "x", "c", "v", "b", "n", "m"]],
    "123": [["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"], ["-", "/", ":", ";", "(", ")", "€", "&", "@", "\""], [".", ",", "?", "!", "'"]],
    "#+=": [["[", "]", "{", "}", "#", "%", "^", "*", "+", "="], ["_", "\\", "|", "~", "<", ">", "$", "£", "¥", "•"], [".", ",", "?", "!", "'"]],
  };

  const ctx = { pop, setPop, type, layer, shift, lp, keyBg, spBg, fg, dark };

  return (
    <div data-kb className="relative pt-1.5 pb-2 px-[3px] select-none" style={{ background: bg }}>
      <div className="flex h-[40px] mb-1.5 items-center">
        {sug.map((s, i) => (
          <button key={i} className="flex-1 text-[16px] truncate px-1" style={{ color: fg, borderLeft: i ? `1px solid ${dark ? "#555" : "#b4b7be"}` : undefined }}
            onClick={() => { const base = value.slice(0, value.length - word.length); onChange(base + s.replace(/[«»]/g, "") + " "); }}>{s}</button>
        ))}
      </div>
      {rows[layer].map((r, ri) => (
        <div key={ri} className="flex mb-[11px]" style={{ padding: ri === 1 && layer === "abc" ? "0 5%" : undefined }}>
          {ri === 2 && (
            layer === "abc" ? (
              <KeyC c={ctx} k="shift" flex={1.35} special onPress={() => { const now = Date.now(); if (now - lastShift.current < 300) setShift(2); else setShift(shift ? 0 : 1); lastShift.current = now; }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill={shift ? fg : "none"} stroke={fg} strokeWidth="1.6"><path d="M12 3L3 12h5v6h8v-6h5z" />{shift === 2 && <path d="M8 21h8" />}</svg>
              </KeyC>
            ) : <KeyC c={ctx} k="sym" flex={1.35} special onPress={() => setLayer(layer === "123" ? "#+=" : "123")}>{layer === "123" ? "#+=" : "123"}</KeyC>
          )}
          {ri === 2 && layer !== "abc" && <div style={{ flex: 0.6 }} />}
          {r.map((k) => <KeyC c={ctx} key={k} k={k} flex={ri === 2 && layer !== "abc" ? 1.3 : 1} />)}
          {ri === 2 && layer !== "abc" && <div style={{ flex: 0.6 }} />}
          {ri === 2 && (
            <KeyC c={ctx} k="del" flex={1.35} special onPress={del}>
              <svg width="24" height="20" viewBox="0 0 26 20" fill="none" stroke={fg} strokeWidth="1.6"><path d="M8 2h15a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H8L1 10z" /><path d="M12 6l8 8M20 6l-8 8" /></svg>
            </KeyC>
          )}
        </div>
      ))}
      <div className="flex">
        <KeyC c={ctx} k="123" flex={1.3} special onPress={() => setLayer(layer === "abc" ? "123" : "abc")}>{layer === "abc" ? "123" : "ABC"}</KeyC>
        <KeyC c={ctx} k="emoji" flex={1.1} special onPress={() => type("😊")}>😊</KeyC>
        <KeyC c={ctx} k=" " flex={5} onPress={() => type(" ")}><span className="text-[15px]">espaço</span></KeyC>
        <KeyC c={ctx} k="ret" flex={2.3} special onPress={() => onChange(value + "\n")}>{"Enter"}</KeyC>
      </div>
      {pop && (
        <div className="absolute pointer-events-none z-10 flex rounded-[10px] shadow-lg" style={{ left: pop.x, top: pop.y - 54, transform: "translateX(-50%)", background: keyBg, color: fg }}>
          {(pop.variants ?? [layer === "abc" && shift ? pop.key.toUpperCase() : pop.key]).map((v, i) => (
            <span key={v} className="w-[34px] h-[50px] flex items-center justify-center text-[28px] rounded-[8px]" style={pop.variants && pop.sel === i ? { background: "#0A84FF", color: "#fff" } : undefined}>{v}</span>
          ))}
        </div>
      )}
    </div>
  );
}

function KeyC({ c, k, flex = 1, special, onPress, children }: { c: any; k: string; flex?: number; special?: boolean; onPress?: () => void; children?: React.ReactNode }) {
  const { pop, setPop, type, layer, shift, lp, keyBg, spBg, fg, dark } = c;
  return (
    <div className="relative" style={{ flex, padding: "0 3px" }}>
      <button
        className="w-full h-[42px] rounded-[5px] flex items-center justify-center select-none"
        style={{ background: special ? spBg : keyBg, color: fg, boxShadow: `0 1px 0 ${dark ? "#1c1c1e" : "#898a8d"}`, fontSize: special ? 15 : 22.5, fontWeight: special ? 400 : 400, touchAction: "none" }}
        onPointerDown={(e) => {
          if (onPress) return;
          const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
          const pr = (e.currentTarget.closest("[data-kb]") as HTMLElement).getBoundingClientRect();
          setPop({ key: k, x: r.left - pr.left + r.width / 2, y: r.top - pr.top });
          const base = k.toLowerCase();
          if (ACCENTS[base] && layer === "abc") lp.current = setTimeout(() => setPop({ key: k, x: r.left - pr.left + r.width / 2, y: r.top - pr.top, variants: ACCENTS[base], sel: 0 }), 380);
        }}
        onPointerMove={(e) => {
          if (!pop?.variants) return;
          const pr = (e.currentTarget.closest("[data-kb]") as HTMLElement).getBoundingClientRect();
          const start = pop.x - (pop.variants.length * 34) / 2;
          setPop({ ...pop, sel: Math.max(0, Math.min(pop.variants.length - 1, Math.floor((e.clientX - pr.left - start) / 34))) });
        }}
        onPointerUp={() => {
          clearTimeout(lp.current);
          if (onPress) { onPress(); return; }
          if (pop?.variants) type(pop.variants[pop.sel ?? 0]); else type(k);
          setPop(null);
        }}
        onPointerLeave={() => { if (!pop?.variants) { clearTimeout(lp.current); setPop(null); } }}
      >
        {children ?? (layer === "abc" && shift ? k.toUpperCase() : k)}
      </button>
    </div>
  );
}
