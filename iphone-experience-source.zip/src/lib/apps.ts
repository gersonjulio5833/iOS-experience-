import { create } from "zustand";
import * as N from "./native";
import { useStore, isFolder, type Item, type Folder } from "./store";

export interface AppEntry {
  id: string;
  pkg: string;
  label: string;
  iosKey?: string; // ícone iOS sugerido
  demo?: boolean;
  internal?: boolean;
}

export type Overlay = "none" | "cc" | "nc" | "spotlight" | "settings";

interface Runtime {
  apps: Record<string, AppEntry>;
  status: N.SystemStatus;
  media: N.MediaInfo | null;
  notifications: N.NotificationInfo[];
  call: N.CallInfo;
  overlay: Overlay;
  settingsPage: string | null;
  locked: boolean;
  editMode: boolean;
  toast: string | null;
  set: (p: Partial<Runtime>) => void;
}

export const useRT = create<Runtime>()((set) => ({
  apps: {},
  status: N.getStatus(),
  media: null,
  notifications: [],
  call: { state: "idle", since: 0 },
  overlay: "none",
  settingsPage: null,
  locked: false,
  editMode: false,
  toast: null,
  set: (p) => set(p),
}));

let toastTimer: any;
export function toast(msg: string) {
  clearTimeout(toastTimer);
  useRT.getState().set({ toast: msg });
  toastTimer = setTimeout(() => useRT.getState().set({ toast: null }), 2600);
}

export const SETTINGS_ID = "ios:settings";

// Pacotes conhecidos -> ícone iOS equivalente
const PKG_MAP: [RegExp, string][] = [
  [/apps\.tachyon|apps\.meetings/, "facetime"],
  [/calendar/, "calendar"],
  [/apps\.photos|gallery/, "photos"],
  [/camera/, "camera"],
  [/^com\.google\.android\.gm$|email|\.mail/, "mail"],
  [/android\.keep|notes|memo/, "notes"],
  [/apps\.tasks|reminder/, "reminders"],
  [/deskclock|\.clock/, "clock"],
  [/apps\.magazines|news/, "news"],
  [/apps\.podcasts/, "podcasts"],
  [/^com\.android\.vending$/, "appstore"],
  [/apps\.maps$/, "maps"],
  [/apps\.fitness|health/, "health"],
  [/walletnfcrel|wallet/, "wallet"],
  [/^com\.android\.settings$/, "settings"],
  [/chrome|browser|firefox|sbrowser/, "safari"],
  [/apps\.messaging|\.mms$|messages/, "messages"],
  [/youtube\.music|\.music/, "music"],
  [/calculator/, "calculator"],
  [/contacts/, "contacts"],
  [/documentsui|nbu\.files|filemanager|\.files/, "files"],
  [/weather/, "weather"],
  [/translate/, "translate"],
  [/recorder/, "voice"],
  [/dialer|\.phone$|incallui/, "phone"],
];

const ROLE_ICON: Record<string, string> = {
  phone: "phone", sms: "messages", browser: "safari", camera: "camera", music: "music", calendar: "calendar",
  gallery: "photos", email: "mail", maps: "maps", clock: "clock", contacts: "contacts", calculator: "calculator",
};

const DEMO: [string, string, string][] = [
  ["facetime", "FaceTime", "FaceTime"], ["calendar", "Calendário", "Calendar"], ["photos", "Fotos", "Photos"], ["camera", "Câmara", "Camera"],
  ["mail", "Mail", "Mail"], ["notes", "Notas", "Notes"], ["reminders", "Lembretes", "Reminders"], ["clock", "Relógio", "Clock"],
  ["news", "News", "News"], ["tv", "TV", "TV"], ["podcasts", "Podcasts", "Podcasts"], ["appstore", "App Store", "App Store"],
  ["maps", "Mapas", "Maps"], ["health", "Saúde", "Health"], ["wallet", "Wallet", "Wallet"], ["settings", "Ajustes", "Settings"],
  ["calculator", "Calculadora", "Calculator"], ["flashlight", "Lanterna", "MyLight"], ["voice", "Gravador", "Voice Memos"], ["weather", "Tempo", "Weather"],
  ["contacts", "Contactos", "Contacts"], ["files", "Ficheiros", "Files"], ["translate", "Traduzir", "Translate"],
  ["phone", "Telefone", "Phone"], ["safari", "Safari", "Safari"], ["messages", "Mensagens", "Messages"], ["music", "Música", "Music"],
];

const FIRST_PAGE_ORDER = ["facetime", "calendar", "photos", "camera", "mail", "notes", "reminders", "clock", "news", "tv", "podcasts", "appstore", "maps", "health", "wallet", "settings"];
const DOCK_ORDER = ["phone", "safari", "messages", "music"];

export function loadApps() {
  const lang = useStore.getState().settings.lang;
  const apps: Record<string, AppEntry> = {};
  if (N.isNative) {
    const roles = N.getRoles();
    const roleByPkg: Record<string, string> = {};
    Object.entries(roles).forEach(([r, p]) => p && ROLE_ICON[r] && (roleByPkg[p] = ROLE_ICON[r]));
    for (const a of N.getApps()) {
      let iosKey = roleByPkg[a.pkg];
      if (!iosKey) for (const [re, k] of PKG_MAP) if (re.test(a.pkg)) { iosKey = k; break; }
      apps[a.id] = { id: a.id, pkg: a.pkg, label: a.label, iosKey };
    }
  } else {
    for (const [k, pt, en] of DEMO) {
      const id = k === "settings" ? SETTINGS_ID : "demo:" + k;
      apps[id] = { id, pkg: id, label: lang === "en" ? en : pt, iosKey: k, demo: k !== "settings", internal: k === "settings" };
    }
  }
  apps[SETTINGS_ID] = { id: SETTINGS_ID, pkg: SETTINGS_ID, label: lang === "en" ? "Settings" : "Ajustes", iosKey: "settings", internal: true };
  useRT.getState().set({ apps });
  reconcile(apps);
}

function capacity() {
  const s = useStore.getState().settings;
  return s.columns * s.rows;
}

function buildDefault(apps: Record<string, AppEntry>) {
  const all = Object.values(apps);
  const used = new Set<string>();
  const pick = (key: string) => {
    if (key === "settings") {
      used.add(SETTINGS_ID);
      return SETTINGS_ID;
    }
    const a = all.find((x) => x.iosKey === key && !used.has(x.id) && !x.internal);
    if (a) used.add(a.id);
    return a?.id;
  };
  const dock = DOCK_ORDER.map(pick).filter(Boolean) as string[];
  const first = FIRST_PAGE_ORDER.map(pick).filter(Boolean) as string[];
  const rest = all.filter((a) => !used.has(a.id)).sort((a, b) => a.label.localeCompare(b.label)).map((a) => a.id);
  const cap = capacity();
  const pages: Item[][] = [];
  const flat = [...first, ...rest];
  for (let i = 0; i < flat.length; i += cap) pages.push(flat.slice(i, i + cap));
  if (!pages.length) pages.push([]);
  return { pages, dock };
}

export function reconcile(apps: Record<string, AppEntry>) {
  const st = useStore.getState();
  const ids = Object.keys(apps);
  if (!st.initialized || !st.pages.length) {
    const { pages, dock } = buildDefault(apps);
    st.patch({ pages, dock, folders: {}, knownApps: ids, initialized: true });
    return;
  }
  const exists = (id: string) => !!apps[id];
  const folders: Record<string, Folder> = {};
  Object.entries(st.folders).forEach(([k, f]) => (folders[k] = { ...f, apps: f.apps.filter(exists) }));
  let pages = st.pages.map((p) =>
    p.filter((it) => (isFolder(it) ? (folders[it.slice(7)]?.apps.length ?? 0) > 0 : exists(it)))
  );
  const dock = st.dock.filter((it) => (isFolder(it) ? (folders[it.slice(7)]?.apps.length ?? 0) > 0 : exists(it)));
  // apps novas -> última página com espaço
  const known = new Set(st.knownApps);
  const cap = capacity();
  const fresh = ids.filter((id) => !known.has(id));
  for (const id of fresh) {
    let last = pages[pages.length - 1];
    if (!last || last.length >= cap) {
      last = [];
      pages.push(last);
    }
    last.push(id);
  }
  pages = pages.filter((p, i) => p.length || i === 0);
  st.patch({ pages, dock, folders, knownApps: ids });
}

// Itens presentes no ecrã inicial (para a Biblioteca de Apps)
export function placedIds() {
  const st = useStore.getState();
  const s = new Set<string>();
  const add = (it: Item) => (isFolder(it) ? st.folders[it.slice(7)]?.apps.forEach((a) => s.add(a)) : s.add(it));
  st.pages.flat().forEach(add);
  st.dock.forEach(add);
  return s;
}

export function openApp(id: string, rect?: DOMRect) {
  const rt = useRT.getState();
  const app = rt.apps[id];
  if (!app) return;
  useStore.getState().countLaunch(id);
  if (app.internal) {
    rt.set({ overlay: "settings", settingsPage: null });
    return;
  }
  if (app.demo) {
    const L = useStore.getState().settings.lang === "en";
    if (app.iosKey === "flashlight") {
      const on = !rt.status.torch;
      N.setTorch(on).then((ok) => {
        useRT.getState().set({ status: { ...useRT.getState().status, torch: ok && on } });
        if (!ok) toast(L ? "Flashlight not supported in this browser" : "Lanterna não suportada neste navegador");
      });
      return;
    }
    toast(L ? `Browser preview: "${app.label}" is a sample icon. Install the APK to open real apps.` : `Pré-visualização no navegador: "${app.label}" é um ícone de exemplo. Instala o APK para abrir apps reais.`);
    return;
  }
  N.launchApp(id, rect);
}
