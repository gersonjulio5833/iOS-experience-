# Relatório de testes e limitações — iPhone Experience 1.0.0

## Testes efectuados no ambiente de desenvolvimento

| Teste | Resultado |
|---|---|
| Verificação TypeScript (`tsc --noEmit`, modo estrito) | ✅ sem erros |
| Build da interface (`npm run build`) | ✅ |
| Compilação Kotlin + APK (`gradle assembleDebug`, AGP 8.2.2, SDK 34, JDK 17) | ✅ `app-debug.apk` ≈ 2 MB |
| `aapt dump badging`: pacote, minSdk 26 / targetSdk 33, actividade HOME + LAUNCHER, UI em `assets/www` | ✅ |
| Teste automatizado da UI (Chrome headless, 412×915 dp = Zenfone 8 Flip) | ✅ sem erros JavaScript |
| — toque prolongado → menu de contexto | ✅ |
| — arrastar uma app para cima de outra → pasta criada | ✅ |
| — deslizar → mudança de página | ✅ |
| — puxar a partir do canto superior direito → Centro de Controlo | ✅ |
| — puxar para baixo → Pesquisa; escrever «cal» → Calendário, Calculadora, pesquisa web | ✅ |
| — tocar na Dynamic Island → expandida (392×199) | ✅ |
| — as 17 páginas de Ajustes são apresentadas | ✅ |
| — ecrã de bloqueio → deslizar para cima → desbloqueio | ✅ (corrigido um defeito: a ilha expandida interceptava o gesto) |

**Não testado:** execução num Zenfone 8 Flip físico (não há dispositivo nem emulador com Google APIs neste ambiente). Recomenda-se verificar no aparelho os pontos assinalados abaixo.

## Comparação com as referências (medido no DOM, ecrã de 412 dp)

| Elemento | Referência (iPhone 393 pt, escalada ×1,048) | Implementado |
|---|---|---|
| Ícone do ecrã inicial | 63 px | 63 px |
| Margem esquerda da grelha | ~28 px | 31 px |
| Passo entre colunas | ~97 px | 96 px |
| Primeira fila (topo) | ~78 px | 73 px |
| Passo entre filas | ~94 px | 99 px (o ecrã de 20:9 é mais alto) |
| Módulos 2×2 do Centro de Controlo | x 45, largura 153 | x 46, largura 153 |
| Módulo Foco (topo) | ~387 px | 385 px |

Cores, transparências e tipografia: vidro translúcido com `backdrop-filter` (desfoque e saturação ajustáveis), ícones em squircle (raio de 22,5 %), fonte Inter (a mais próxima do SF Pro e de uso livre), relógio do bloqueio com peso 200 (fino) ou 650 (arredondado, como na referência).

## Funcionalidades reais (no APK)
- Launcher HOME predefinido; abre apps reais com animação de revelação a partir do ícone.
- Lista das apps instaladas, ícones originais (adaptativos compostos), actualização automática ao instalar ou desinstalar.
- Grelha de 4 colunas (ou 5), 5 a 7 filas, várias páginas, dock com 4 apps, pastas, arrastar e largar, Biblioteca de Apps, pesquisa de apps e pesquisa web.
- Ícones estilo iOS para as apps de sistema (telefone, mensagens, câmara, navegador…), alteráveis por app; as restantes mantêm o ícone original.
- Lanterna (CameraManager), volume multimédia (AudioManager).
- Brilho do sistema e bloqueio de rotação, com a permissão «Modificar definições do sistema». Sem ela, o brilho só muda dentro do Launcher, e isso é indicado na interface.
- Não incomodar e modo silencioso, com o acesso à política de notificações.
- Música actual real (título, artista, capa, progresso, reproduzir/pausar/anterior/seguinte/procurar) via MediaSession.
- Notificações reais: agrupadas por app, abrem a app de origem, deslizar para dispensar, limpar tudo, privacidade das pré-visualizações.
- Estado das chamadas (a receber / em curso, com tempo decorrido) na Dynamic Island, com a permissão Telefone.
- Indicador de carregamento na Dynamic Island (evento real da bateria).
- Teclado iOS como método de introdução: QWERTY, números, símbolos, acentos PT por pressão prolongada, sugestões, maiúsculas automáticas, ponto com duplo espaço, modo escuro.
- Preferências guardadas localmente (disposição, pastas, ícones, ajustes).

## Limitações impostas pelo Android (sem root)
| Função | Comportamento |
|---|---|
| Wi-Fi, Bluetooth, dados móveis, modo de voo, ponto de acesso, NFC | O estado é lido de verdade; tocar **abre o painel oficial** (o Android 10+ não permite que apps os liguem ou desliguem). |
| Ecrã de bloqueio | **Complementar**, identificado como tal. Não substitui o PIN ou a impressão digital. Em «Automático» só aparece se o aparelho não tiver bloqueio seguro. |
| Centro de Controlo, Notificações, Dynamic Island | Funcionam **dentro do Launcher**. Não substituem o painel do sistema nem aparecem por cima de outras apps (seria preciso uma sobreposição e um serviço de acessibilidade). |
| Barra de estado Android | Ocultada no Launcher (configurável). Deslizar a partir da margem mostra-a temporariamente. |
| Botão ⏻ | Abre o ecrã complementar; não desliga nem bloqueia o aparelho. |
| Dynamic Island no Zenfone 8 Flip | Não existe orifício de câmara (a câmara é rotativa). A ilha é desenhada ao centro, com posição e tamanho ajustáveis. |
| Teclado | Sem correcção automática nem escrita por deslize. Dicionário PT pequeno, offline. |

## Consumo de recursos
- Sem serviços em segundo plano próprios: apenas o NotificationListener do sistema, se for activado.
- Sem consultas periódicas: o estado é actualizado por eventos do sistema, agrupados em 120 ms.
- O progresso multimédia só é animado com a ilha expandida.
- Ícones em cache LRU de 6 MB.
- Os desfoques podem ser reduzidos em *Ajustes › Transparência* para poupar GPU.
- WebView: memória típica de 80 a 150 MB, superior à de um launcher puramente nativo. É o compromisso escolhido para obter a máxima fidelidade visual.
